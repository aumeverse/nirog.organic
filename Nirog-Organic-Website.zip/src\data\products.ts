﻿import { Product } from '@/types';

export const products: Product[] = [
  { 
    id: "p1", 
    name: "Pure Black Mustard Oil", 
    price: 349, 
    unit: "1L", 
    category: "Oils", 
    img1: "https://i.ibb.co/39HK9h3x/mustrd.jpg", 
    variants: [ {u: "1L", p: 349}, {u: "5L", p: 1649} ], 
    benefits: ["Woodpressed", "Omega-3 Rich"], 
    isBestseller: true 
  },
  { 
    id: "p2", 
    name: "Pure Yellow Mustard Oil", 
    price: 459, 
    unit: "1L", 
    category: "Oils", 
    img1: "https://i.ibb.co/LzVxBmwj/yello-sarso.jpg", 
    variants: [ {u: "1L", p: 459}, {u: "5L", p: 2249} ], 
    benefits: ["Golden Sarso Seeds", "Vitamin E"], 
    isBestseller: true 
  },
  { 
    id: "p20", 
    name: "Sesame Oil", 
    price: 299, 
    unit: "500ml", 
    category: "Oils", 
    img1: "https://i.ibb.co/3Y1CL7m7/ssesameoil.jpg", 
    variants: [{u: "500ml", p: 299}, {u: "1L", p: 579}], 
    benefits: ["Copper/Calcium"], 
    isBestseller: true 
  },
  { 
    id: "p3", 
    name: "Pure Coconut Oil", 
    price: 799, 
    unit: "1L", 
    category: "Oils", 
    img1: "https://i.ibb.co/JRkP18SM/cocnut.jpg", 
    variants: [ {u: "100ml", p: 99}, {u: "500ml", p: 399}, {u: "1L", p: 799} ], 
    benefits: ["Virgin/Raw", "Moisturizer"], 
    isBestseller: true 
  },
  { 
    id: "p5", 
    name: "Pure Badam Oil", 
    price: 349, 
    unit: "100ml", 
    category: "Oils", 
    img1: "https://i.ibb.co/7ttstkt7/almond-oil.jpg", 
    benefits: ["Gurbandi Almonds"] 
  },
  { 
    id: "p22", 
    name: "Pure Groundnut Oil", 
    price: 399, 
    unit: "1L", 
    category: "Oils", 
    img1: "https://i.ibb.co/jZWyRnJK/mumfali.jpg", 
    benefits: ["Monounsaturated Fats"] 
  },
  { 
    id: "p21", 
    name: "Jaggery", 
    price: 199, 
    unit: "1kg", 
    category: "Sweeteners", 
    img1: "https://i.ibb.co/jPZZ5XMr/jaggery.jpg", 
    benefits: ["Unrefined", "Blood Purifier"], 
    isOutOfStock: true 
  },
  { 
    id: "p6", 
    name: "Wheat Atta", 
    price: 69, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/tTGzfGZt/wheat.jpg", 
    variants: [ {u: "1kg", p: 69}, {u: "5kg", p: 349}, {u: "10kg", p: 699} ], 
    benefits: ["Stone-ground", "Whole Grain"] 
  },
  { 
    id: "p7", 
    name: "MP Wheat Atta", 
    price: 54, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/7d6YFFJH/mp.jpg", 
    variants: [ {u: "1kg", p: 54}, {u: "5kg", p: 274}, {u: "10kg", p: 549} ], 
    benefits: ["High Protein"], 
    isBestseller: true 
  },
  { 
    id: "p16", 
    name: "Black Wheat Flour", 
    price: 129, 
    unit: "1kg", 
    category: "Heritage Flours", 
    img1: "https://i.ibb.co/QvZ5tvcf/black-wheat-flour.jpg", 
    benefits: ["Anthocyanins", "Low GI"], 
    isBestseller: true 
  },
  { 
    id: "p17", 
    name: "Paigambari Wheat", 
    price: 179, 
    unit: "1kg", 
    category: "Heritage Flours", 
    img1: "https://i.ibb.co/Zp8qVrdY/paigambar-wheat-flour.jpg", 
    benefits: ["Heirloom Strain", "Low Gluten"] 
  },
  { 
    id: "p15", 
    name: "Haldi (Turmeric)", 
    price: 180, 
    unit: "200g", 
    category: "Spices", 
    img1: "https://i.ibb.co/ym6yQGtL/haldi.jpg", 
    variants: [{u: "200g", p: 180}, {u: "1kg", p: 700}], 
    benefits: ["7% Curcumin"] 
  },
  { 
    id: "p18", 
    name: "Bansi Wheat", 
    price: 149, 
    unit: "1kg", 
    category: "Heritage Flours", 
    img1: "https://i.ibb.co/9m4scDfQ/bansi.jpg", 
    benefits: ["Ancient Variety"] 
  },
  { 
    id: "p19", 
    name: "Makki Atta", 
    price: 89, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/pspPmBs/maize.jpg", 
    benefits: ["Zinc/Iron"] 
  },
  { 
    id: "p8", 
    name: "Multigrain Atta", 
    price: 119, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/MDNxgs00/multi.jpg", 
    benefits: ["7 Grain Blend"] 
  },
  { 
    id: "p9", 
    name: "Ragi Atta", 
    price: 149, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/d023GfJz/63bb1e96-ea50-432b-93ff-da15e5d7623a.png", 
    benefits: ["Calcium Rich"] 
  },
  { 
    id: "p10", 
    name: "Jowar Atta", 
    price: 129, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/RT8Xxvkj/83375485-4b49-41c8-be9f-561b99436307.png", 
    benefits: ["Gluten-Free"] 
  },
  { 
    id: "p11", 
    name: "Jau Atta", 
    price: 129, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/KxczQb98/166355b5-a465-406f-9781-025c57e5b4f1.png", 
    benefits: ["Cooling Grain"] 
  },
  { 
    id: "p12", 
    name: "Besan", 
    price: 159, 
    unit: "1kg", 
    category: "Flours", 
    img1: "https://i.ibb.co/twHt1WcL/cd7e094a-34b2-4339-91eb-c4446f31529c.png", 
    benefits: ["100% Chana Dal"] 
  },
  { 
    id: "p13", 
    name: "Organic Black Wheat Dalia", 
    price: 80, 
    unit: "500g", 
    category: "Grains", 
    img1: "https://i.ibb.co/tM976W1b/aa227679-7f64-4580-b9a0-c3661c2b3bec.png", 
    variants: [{u: "500g", p: 80}, {u: "1kg", p: 150}], 
    benefits: ["High Fiber"] 
  },
  { 
    id: "nirogcard", 
    name: "Nirog Card", 
    price: 1, 
    unit: "1pc", 
    category: "Gift Cards", 
    img1: "https://i.ibb.co/99WTC1Nr/Gemini-Generated-Image-i4zsaxi4zsaxi4zs.png", 
    benefits: ["Exclusive Heritage Membership", "Support Punjab Farmers"], 
    isBestseller: true 
  }
];
