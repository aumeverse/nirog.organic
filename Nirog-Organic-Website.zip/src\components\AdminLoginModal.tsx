﻿'use client';

import React, { useState } from 'react';
import { X, Lock, ShieldCheck } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { useCart } from '@/context/CartContext';
import { PageView } from '@/types';

interface AdminLoginModalProps {
  onNavigate: (view: PageView) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({ onNavigate }) => {
  const { isLoginModalOpen, closeLoginModal, login } = useProducts();
  const { showToast } = useCart();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  if (!isLoginModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const success = login(username, password);
    if (success) {
      showToast('Welcome back, Jagmindar Singh!');
      onNavigate('admin');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setError('Invalid username or password. Please check your credentials and try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={closeLoginModal}
      />
      <div className="relative z-10 w-full max-w-md bg-punjab-cream rounded-3xl p-8 shadow-2xl border border-punjab-gold/20 animate-fade-in-up">
        <button
          onClick={closeLoginModal}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-punjab text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-punjab/20">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-punjab-soil">Admin Panel Access</h2>
          <p className="text-xs text-gray-500 mt-1">
            Restricted portal for Nirog Organic store management.
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl p-3 mb-4 font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-gray-600 mb-1.5">
              Username
            </label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter admin username"
              autoComplete="username"
              className="w-full p-3 bg-white border border-gray-200 rounded-xl outline-none focus:border-punjab transition-all text-sm font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-gray-600 mb-1.5">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              className="w-full p-3 bg-white border border-gray-200 rounded-xl outline-none focus:border-punjab transition-all text-sm font-medium"
            />
          </div>

          <div className="bg-punjab-wheat/40 rounded-xl p-3 border border-punjab-gold/20 text-[11px] text-punjab-soil flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-punjab flex-shrink-0" />
            <span>Encrypted administrative session. Verified access only.</span>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl font-bold shadow-lg transition-all hover:scale-[1.01] cursor-pointer text-sm"
          >
            Unlock Admin Panel
          </button>
        </form>
      </div>
    </div>
  );
};
