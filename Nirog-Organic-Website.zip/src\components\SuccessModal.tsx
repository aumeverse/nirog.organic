﻿'use client';

import React from 'react';
import { X, Check, MessageCircle } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useProducts } from '@/context/ProductContext';

export const SuccessModal: React.FC = () => {
  const { isSuccessModalOpen, closeSuccessModal } = useCart();
  const { storeSettings } = useProducts();
  const waPhone = storeSettings.whatsappNumber || '917009395451';

  if (!isSuccessModalOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-white rounded-3xl p-8 max-w-md w-full text-center shadow-2xl relative animate-fade-in-up">
        <button
          onClick={closeSuccessModal}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-6 h-6" />
        </button>
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check className="w-10 h-10 text-green-600" />
        </div>
        <h2 className="font-serif text-2xl font-bold text-gray-800 mb-2">
          Order placed successfully ✅
        </h2>
        <p className="text-gray-600 mb-4 text-sm">
          Thank you for choosing Nirog Organic. Your order is now confirmed and will be processed shortly.
        </p>
        <p className="text-sm text-gray-500 mb-6">
          For any queries or changes, connect with us on WhatsApp.
        </p>
        <a
          href={`https://wa.me/${waPhone}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-green-600 font-bold hover:underline bg-green-50 px-6 py-3 rounded-xl hover:bg-green-100 transition-colors text-sm"
        >
          <MessageCircle className="w-5 h-5" /> Chat on WhatsApp
        </a>
        <button
          onClick={closeSuccessModal}
          className="block w-full mt-6 text-sm text-gray-400 hover:text-gray-600 cursor-pointer"
        >
          Close
        </button>
      </div>
    </div>
  );
};
