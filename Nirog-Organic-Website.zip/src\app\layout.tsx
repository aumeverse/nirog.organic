﻿import type { Metadata, Viewport } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import './globals.css';
import { ProductProvider } from '@/context/ProductContext';
import { CartProvider } from '@/context/CartContext';

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600'],
  variable: '--font-sans',
  display: 'swap',
});

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-serif',
  display: 'swap',
});

export const metadata: Metadata = {
  title: "Nirog Organic | Punjab's Living Heritage",
  description: "Pure stone-ground flours and cold-pressed oils direct from Punjab's 2000+ heritage farmers.",
};

export const viewport: Viewport = {
  themeColor: '#659D32',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`scroll-smooth ${inter.variable} ${playfair.variable}`}>
      <body className="font-sans antialiased selection:bg-punjab-gold selection:text-punjab-soil bg-[#f0e6d8] text-[#1a1a1a]">
        <ProductProvider>
          <CartProvider>
            {children}
          </CartProvider>
        </ProductProvider>
      </body>
    </html>
  );
}
