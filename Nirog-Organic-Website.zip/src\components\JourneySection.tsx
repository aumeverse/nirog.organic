﻿'use client';

import React from 'react';

const steps = [
  {
    step: "1. Golden Fields",
    desc: "Handpicked from sun-kissed fields of Punjab.",
    img: "https://i.ibb.co/srvp6fS/unnamed-2.jpg",
    fallback: "https://placehold.co/600x400/F0E6D8/854D0E?text=Golden+Fields"
  },
  {
    step: "2. Stone-Ground",
    desc: "Crushed slowly between granite wheels for nutrition.",
    img: "https://i.ibb.co/99WTC1Nr/Gemini-Generated-Image-i4zsaxi4zsaxi4zs.png",
    fallback: "https://placehold.co/600x400/F0E6D8/854D0E?text=Stone+Grinding"
  },
  {
    step: "3. Woodpressed",
    desc: "Extracted below 40°C with zero chemicals.",
    img: "https://i.ibb.co/t1LJgC9/Gemini-Generated-Image-sugd5csugd5csugd.png",
    fallback: "https://placehold.co/600x400/F0E6D8/854D0E?text=Wood+Pressing"
  }
];

export const JourneySection: React.FC = () => {
  return (
    <section id="heritage-section" className="py-20 bg-punjab-cream">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl sm:text-4xl text-punjab-soil font-bold">The Journey of Purity</h2>
          <div className="w-20 h-1 bg-punjab mx-auto mt-4 rounded-full"></div>
        </div>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          {steps.map((item, idx) => (
            <div key={idx} className="journey-step">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.img}
                alt={item.step}
                className="w-full h-64 object-cover rounded-3xl shadow-lg mb-6 hover:scale-105 transition-all duration-500"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = item.fallback;
                }}
              />
              <h3 className="font-serif text-2xl font-bold text-punjab-dark">{item.step}</h3>
              <p className="text-gray-600 mt-2 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
