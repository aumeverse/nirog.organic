﻿'use client';

import React from 'react';
import { X, ArrowRight } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { PageView } from '@/types';

interface CartSidebarProps {
  onNavigate: (view: PageView) => void;
}

export const CartSidebar: React.FC<CartSidebarProps> = ({ onNavigate }) => {
  const { isCartOpen, closeCart, cartItems, subtotal, updateQty } = useCart();

  const handleCheckout = () => {
    closeCart();
    onNavigate('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Overlay */}
      <div
        onClick={closeCart}
        className={`fixed inset-0 bg-black/50 z-40 backdrop-blur-sm transition-opacity duration-300 ${
          isCartOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      />

      {/* Slide-over Drawer */}
      <div
        id="cart-sidebar"
        className={`fixed inset-y-0 right-0 w-full md:w-96 bg-punjab-cream shadow-2xl transition-transform duration-300 z-50 flex flex-col ${
          isCartOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-6 bg-punjab text-white flex justify-between items-center shadow-md">
          <h2 className="font-serif text-2xl font-bold">Harvest Box</h2>
          <button
            onClick={closeCart}
            className="hover:opacity-80 transition-opacity cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div id="cart-items" className="flex-1 overflow-y-auto p-6 space-y-4">
          {cartItems.length === 0 ? (
            <p className="text-center opacity-50 py-16 text-sm">Harvest Box is empty</p>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.cartId}
                className="flex items-center gap-4 bg-white p-3 rounded-xl shadow-sm border border-gray-100"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.product.img1}
                  alt={item.product.name}
                  className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://placehold.co/100x100/F0E6D8/854D0E?text=Product';
                  }}
                />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold truncate text-gray-900">{item.product.name}</div>
                  <p className="font-normal text-xs text-gray-500">
                    ₹{item.price} / {item.variantUnit}
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-2 py-1 border border-gray-200">
                  <button
                    onClick={() => updateQty(item.cartId, -1)}
                    className="p-1 text-punjab font-bold hover:text-punjab-dark cursor-pointer text-sm"
                    aria-label="Decrease quantity"
                  >
                    -
                  </button>
                  <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateQty(item.cartId, 1)}
                    className="p-1 text-punjab font-bold hover:text-punjab-dark cursor-pointer text-sm"
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-6 border-t border-punjab-gold/20 bg-punjab-cream">
          <div className="flex justify-between items-center mb-6">
            <span className="text-gray-600 font-bold">Subtotal</span>
            <span id="cart-total" className="font-bold text-2xl text-punjab-dark">
              ₹{subtotal}
            </span>
          </div>
          <button
            onClick={handleCheckout}
            disabled={cartItems.length === 0}
            className={`w-full py-4 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-all ${
              cartItems.length === 0
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-green-600 hover:bg-green-700 text-white hover:scale-[1.02] cursor-pointer'
            }`}
          >
            Checkout Now <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </>
  );
};
