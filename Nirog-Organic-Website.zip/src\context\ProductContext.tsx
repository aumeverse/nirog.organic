﻿'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  ShippingConfig,
  StoreSettings,
  OfferBarConfig,
  HeroConfig,
  VideoItem
} from '@/types';
import { products as defaultProducts } from '@/data/products';
import { defaultShippingConfig } from '@/utils/shipping';

export const defaultStoreSettings: StoreSettings = {
  whatsappNumber: '917009395451',
  offerBar: {
    enabled: true,
    color: 'red',
    headline: 'SPECIAL HARVEST OFFER: FLAT 15% OFF ON ALL FLOURS',
    description: 'Use code PUNJAB15 at checkout • 100% Stone-Ground & Chemical Free • Free Shipping over ₹999'
  },
  hero: {
    headline: "Punjab's Living Heritage",
    subheadline: 'Slow stone-ground flours and woodpressed oils direct from the source.',
    tagline: 'Premium Organic Products',
    buttonText: 'View The Pantry'
  },
  videos: [
    {
      id: 'vid_1',
      title: 'About Nirog Organic',
      url: 'https://www.instagram.com/reel/DUV0w0tj8Ib/',
      caption: 'Pure stone-ground milling and cold-pressing directly from 2,000+ heritage farmers in Punjab.'
    }
  ]
};

interface ProductContextType {
  products: Product[];
  shippingConfig: ShippingConfig;
  storeSettings: StoreSettings;
  isAuthenticated: boolean;
  isLoginModalOpen: boolean;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updated: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  resetProducts: () => void;
  updateShippingConfig: (config: ShippingConfig) => void;
  resetShippingConfig: () => void;
  updateStoreSettings: (settings: Partial<StoreSettings>) => void;
  updateOfferBar: (bar: Partial<OfferBarConfig>) => void;
  updateHero: (hero: Partial<HeroConfig>) => void;
  updateWhatsappNumber: (num: string) => void;
  addVideo: (video: VideoItem) => void;
  updateVideo: (id: string, updated: Partial<VideoItem>) => void;
  deleteVideo: (id: string) => void;
  resetStoreSettings: () => void;
  login: (u: string, p: string) => boolean;
  logout: () => void;
  updateCredentials: (newU: string, newP: string) => void;
  openLoginModal: () => void;
  closeLoginModal: () => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

const LOCKED_DEFAULT_CREDS = {
  u: 'jagmindarsingh',
  p: 'nirogorganic'
};

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(defaultProducts);
  const [shippingConfig, setShippingConfig] = useState<ShippingConfig>(defaultShippingConfig);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(defaultStoreSettings);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [credentials, setCredentials] = useState<{ u: string; p: string }>(LOCKED_DEFAULT_CREDS);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const savedProducts = localStorage.getItem('nirogProducts');
      if (savedProducts) {
        const parsed = JSON.parse(savedProducts);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setProducts(parsed);
        }
      }

      const savedShipping = localStorage.getItem('nirogShippingConfig');
      if (savedShipping) {
        const parsed = JSON.parse(savedShipping);
        if (parsed && parsed.punjab && parsed.restOfIndia) {
          setShippingConfig(parsed);
        }
      }

      const savedSettings = localStorage.getItem('nirogStoreSettings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        if (parsed) {
          setStoreSettings({
            whatsappNumber: parsed.whatsappNumber || defaultStoreSettings.whatsappNumber,
            offerBar: { ...defaultStoreSettings.offerBar, ...(parsed.offerBar || {}) },
            hero: { ...defaultStoreSettings.hero, ...(parsed.hero || {}) },
            videos: Array.isArray(parsed.videos) && parsed.videos.length > 0 ? parsed.videos : defaultStoreSettings.videos
          });
        }
      }

      const savedCreds = localStorage.getItem('nirogAdminCreds');
      if (savedCreds) {
        const parsed = JSON.parse(savedCreds);
        if (parsed && parsed.u && parsed.p && parsed.u !== 'admin') {
          setCredentials(parsed);
        } else {
          setCredentials(LOCKED_DEFAULT_CREDS);
          localStorage.setItem('nirogAdminCreds', JSON.stringify(LOCKED_DEFAULT_CREDS));
        }
      } else {
        localStorage.setItem('nirogAdminCreds', JSON.stringify(LOCKED_DEFAULT_CREDS));
      }

      const savedAuth = sessionStorage.getItem('nirogAdminAuth');
      if (savedAuth === 'true') {
        setIsAuthenticated(true);
      }
    } catch (e) {
      console.error('Failed to load stored product/admin state:', e);
    }
    setIsInitialized(true);
  }, []);

  // Save products
  useEffect(() => {
    if (!isInitialized) return;
    try {
      localStorage.setItem('nirogProducts', JSON.stringify(products));
    } catch (e) {
      console.error('Failed to persist products:', e);
    }
  }, [products, isInitialized]);

  // Save shipping config
  useEffect(() => {
    if (!isInitialized) return;
    try {
      localStorage.setItem('nirogShippingConfig', JSON.stringify(shippingConfig));
    } catch (e) {
      console.error('Failed to persist shipping config:', e);
    }
  }, [shippingConfig, isInitialized]);

  // Save store settings
  useEffect(() => {
    if (!isInitialized) return;
    try {
      localStorage.setItem('nirogStoreSettings', JSON.stringify(storeSettings));
    } catch (e) {
      console.error('Failed to persist store settings:', e);
    }
  }, [storeSettings, isInitialized]);

  // Save credentials
  useEffect(() => {
    if (!isInitialized) return;
    try {
      localStorage.setItem('nirogAdminCreds', JSON.stringify(credentials));
    } catch (e) {
      console.error('Failed to persist credentials:', e);
    }
  }, [credentials, isInitialized]);

  const addProduct = (product: Product) => {
    setProducts(prev => [product, ...prev]);
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updated } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const resetProducts = () => {
    setProducts(defaultProducts);
    try {
      localStorage.removeItem('nirogProducts');
    } catch {}
  };

  const updateShippingConfig = (config: ShippingConfig) => {
    setShippingConfig(config);
  };

  const resetShippingConfig = () => {
    setShippingConfig(defaultShippingConfig);
    try {
      localStorage.removeItem('nirogShippingConfig');
    } catch {}
  };

  const updateStoreSettings = (settings: Partial<StoreSettings>) => {
    setStoreSettings(prev => ({ ...prev, ...settings }));
  };

  const updateOfferBar = (bar: Partial<OfferBarConfig>) => {
    setStoreSettings(prev => ({
      ...prev,
      offerBar: { ...prev.offerBar, ...bar }
    }));
  };

  const updateHero = (hero: Partial<HeroConfig>) => {
    setStoreSettings(prev => ({
      ...prev,
      hero: { ...prev.hero, ...hero }
    }));
  };

  const updateWhatsappNumber = (num: string) => {
    const cleaned = num.replace(/\D/g, '');
    setStoreSettings(prev => ({
      ...prev,
      whatsappNumber: cleaned || prev.whatsappNumber
    }));
  };

  const addVideo = (video: VideoItem) => {
    setStoreSettings(prev => ({
      ...prev,
      videos: [...prev.videos, video]
    }));
  };

  const updateVideo = (id: string, updated: Partial<VideoItem>) => {
    setStoreSettings(prev => ({
      ...prev,
      videos: prev.videos.map(v => (v.id === id ? { ...v, ...updated } : v))
    }));
  };

  const deleteVideo = (id: string) => {
    setStoreSettings(prev => ({
      ...prev,
      videos: prev.videos.filter(v => v.id !== id)
    }));
  };

  const resetStoreSettings = () => {
    setStoreSettings(defaultStoreSettings);
    try {
      localStorage.removeItem('nirogStoreSettings');
    } catch {}
  };

  const login = (u: string, p: string): boolean => {
    const trimmedU = u.trim();
    const trimmedP = p.trim();
    const isValid =
      (trimmedU === credentials.u && trimmedP === credentials.p) ||
      (trimmedU === LOCKED_DEFAULT_CREDS.u && trimmedP === LOCKED_DEFAULT_CREDS.p);

    if (isValid) {
      setIsAuthenticated(true);
      try {
        sessionStorage.setItem('nirogAdminAuth', 'true');
      } catch {}
      setIsLoginModalOpen(false);
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    try {
      sessionStorage.removeItem('nirogAdminAuth');
    } catch {}
  };

  const updateCredentials = (newU: string, newP: string) => {
    const updated = { u: newU.trim(), p: newP.trim() };
    setCredentials(updated);
    try {
      localStorage.setItem('nirogAdminCreds', JSON.stringify(updated));
    } catch {}
  };

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  return (
    <ProductContext.Provider
      value={{
        products,
        shippingConfig,
        storeSettings,
        isAuthenticated,
        isLoginModalOpen,
        addProduct,
        updateProduct,
        deleteProduct,
        resetProducts,
        updateShippingConfig,
        resetShippingConfig,
        updateStoreSettings,
        updateOfferBar,
        updateHero,
        updateWhatsappNumber,
        addVideo,
        updateVideo,
        deleteVideo,
        resetStoreSettings,
        login,
        logout,
        updateCredentials,
        openLoginModal,
        closeLoginModal,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};
