﻿'use client';

import React from 'react';
import { Sprout, Lock, Shield } from 'lucide-react';
import { PageView } from '@/types';
import { useProducts } from '@/context/ProductContext';

interface FooterProps {
  onNavigate: (view: PageView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { isAuthenticated, openLoginModal } = useProducts();

  const handleAdminClick = () => {
    if (isAuthenticated) {
      onNavigate('admin');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      openLoginModal();
    }
  };

  return (
    <footer className="bg-punjab-soil text-white py-16">
      <div className="container mx-auto px-6 grid md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <Sprout className="w-6 h-6 text-punjab-gold" />
            <span className="font-serif font-bold text-2xl">Nirog Organic</span>
          </div>
          <p className="text-white max-w-sm opacity-90 text-sm leading-relaxed">
            Reviving the &apos;Sanjha Chulha&apos; of Punjab. Pure, ethical, and steeped in tradition.
          </p>
          <div className="mt-6">
            <a
              href="https://www.instagram.com/nirog.organic?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-punjab-gold hover:text-white transition-colors font-bold text-sm"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
              </svg>
              Follow us on Instagram
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-serif font-bold text-lg mb-6 text-punjab-gold">Links</h4>
          <ul className="space-y-2.5 text-sm">
            <li>
              <button
                onClick={() => {
                  onNavigate('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-white hover:text-punjab-gold transition-colors font-bold cursor-pointer"
              >
                Home
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onNavigate('shop');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-white hover:text-punjab-gold transition-colors font-bold cursor-pointer"
              >
                Shop All
              </button>
            </li>
            <li>
              <button
                onClick={handleAdminClick}
                className="inline-flex items-center gap-1.5 text-punjab-gold/90 hover:text-punjab-gold transition-colors font-bold cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" /> Admin Panel
              </button>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-serif font-bold text-lg mb-6 text-punjab-gold">Legal</h4>
          <ul className="space-y-2.5 text-sm">
            <li>
              <a href="#" className="text-white hover:text-punjab-gold transition-colors font-bold">
                Privacy Policy
              </a>
            </li>
            <li>
              <a href="#" className="text-white hover:text-punjab-gold transition-colors font-bold">
                Terms & Conditions
              </a>
            </li>
            <li className="pt-2">
              <button
                onClick={handleAdminClick}
                className="text-xs text-white/50 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Shield className="w-3 h-3" /> Staff Portal
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div className="container mx-auto px-6 mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-white/50 gap-4">
        <span>&copy; 2025 Nirog Organic. Made with ❤️ in Punjab.</span>
        <button
          onClick={handleAdminClick}
          className="text-white/40 hover:text-punjab-gold transition-colors cursor-pointer text-[11px] flex items-center gap-1"
        >
          <Lock className="w-3 h-3" /> Admin / Edmund Panel
        </button>
      </div>
    </footer>
  );
};
