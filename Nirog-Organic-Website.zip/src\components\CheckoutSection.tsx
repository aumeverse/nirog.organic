﻿'use client';

import React, { useState } from 'react';
import { ArrowLeft, User, MapPin, MessageCircle } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useProducts } from '@/context/ProductContext';
import { calculateShipping } from '@/utils/shipping';
import { PageView, CheckoutFormData } from '@/types';

interface CheckoutSectionProps {
  onNavigate: (view: PageView) => void;
}

const indianStates = [
  'Punjab',
  'Haryana',
  'Delhi',
  'Chandigarh',
  'Himachal Pradesh',
  'Rajasthan',
  'Uttar Pradesh',
  'Uttarakhand',
  'Maharashtra',
  'Karnataka',
  'Telangana',
  'Gujarat',
  'Tamil Nadu',
  'West Bengal',
  'Other'
];

export const CheckoutSection: React.FC<CheckoutSectionProps> = ({ onNavigate }) => {
  const { cartItems, subtotal, totalWeight, clearCart, showToast, openSuccessModal } = useCart();
  const { storeSettings, shippingConfig } = useProducts();

  const [formData, setFormData] = useState<CheckoutFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    pincode: '',
    state: 'Punjab'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const shippingCost = calculateShipping(totalWeight, formData.state);
  const totalPayable = subtotal + shippingCost;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (cartItems.length === 0) {
      showToast('Harvest Box is empty!');
      return;
    }

    if (!formData.phone.match(/^[0-9]{10}$/)) {
      showToast('Please enter a valid 10-digit phone number');
      return;
    }

    if (!formData.pincode.match(/^[0-9]{6}$/)) {
      showToast('Please enter a valid 6-digit pincode');
      return;
    }

    setIsSubmitting(true);

    const productDetailsArr = cartItems.map(item => {
      const variantLabel = item.variantUnit ? ` (${item.variantUnit})` : '';
      return `${item.product.name}${variantLabel} x ${item.quantity}`;
    });

    const productsStr = productDetailsArr.join(', ');
    const clientOrderId = `ORDER_${Date.now()}`;

    let rawWaText = `*New Order from Nirog Organic*\n\n`;
    rawWaText += `*Customer:* ${formData.firstName} ${formData.lastName}\n`;
    rawWaText += `*Phone:* ${formData.phone}\n`;
    rawWaText += `*Email:* ${formData.email}\n`;
    rawWaText += `*Address:* ${formData.address}, ${formData.city}, ${formData.pincode}, ${formData.state}\n\n`;
    rawWaText += `*Products:*\n`;
    productDetailsArr.forEach(item => {
      rawWaText += `- ${item}\n`;
    });
    rawWaText += `\n*Subtotal:* ₹${subtotal}\n`;
    rawWaText += `*Shipping:* ₹${shippingCost}\n`;
    rawWaText += `*Total Payable: ₹${totalPayable}*`;

    const waPhone = storeSettings.whatsappNumber || '917009395451';
    const waUrl = `https://wa.me/${waPhone}?text=${encodeURIComponent(rawWaText)}`;

    try {
      // N8N PRE-PAYMENT WEBHOOK
      fetch('https://primary-production-fd532.up.railway.app/webhook/nirog-pre-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_order_id: clientOrderId,
          name: `${formData.firstName} ${formData.lastName}`,
          email: formData.email,
          phone: formData.phone,
          products: productsStr,
          address: `${formData.address}, ${formData.city}, ${formData.pincode}, ${formData.state}`,
          amount: totalPayable,
          status: 'WHATSAPP_REDIRECT'
        })
      }).catch(err => console.error('Webhook logging failed:', err));

      // Clear cart
      clearCart();

      // Open WhatsApp in new tab
      window.open(waUrl, '_blank');

      // Navigate home and show confirmation modal
      onNavigate('home');
      openSuccessModal();
    } catch (err) {
      console.error(err);
      showToast('Unable to process order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="page-checkout" className="pt-32 pb-20 bg-punjab-cream min-h-screen">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-8">
          <button
            onClick={() => {
              onNavigate('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center text-punjab-dark font-medium hover:text-punjab-gold transition-colors mb-4 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5 mr-2" /> Back to Shop
          </button>
          <h1 className="font-serif text-3xl font-bold text-punjab-soil">Secure Checkout</h1>
          <p className="text-gray-500 mt-2">Complete your details to confirm your order.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-6 sm:p-8 border border-gray-100">
          <form onSubmit={handleSubmit} id="checkout-form">
            {/* Personal Details */}
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <User className="w-5 h-5 text-punjab-gold" /> Personal Details
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                id="firstName"
                placeholder="First Name"
                value={formData.firstName}
                onChange={handleChange}
                required
                className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
              />
              <input
                type="text"
                id="lastName"
                placeholder="Last Name"
                value={formData.lastName}
                onChange={handleChange}
                required
                className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
              />
            </div>
            <div className="mb-4">
              <input
                type="email"
                id="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
              />
            </div>
            <div className="relative mb-8">
              <input
                type="tel"
                id="phone"
                placeholder="Phone Number (10 digits)"
                value={formData.phone}
                onChange={handleChange}
                required
                pattern="[0-9]{10}"
                className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
              />
            </div>

            {/* Delivery Address */}
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2 pt-4 border-t border-gray-100">
              <MapPin className="w-5 h-5 text-punjab-gold" /> Delivery Address
            </h3>
            <div className="space-y-4 mb-8">
              <input
                type="text"
                id="address"
                placeholder="Shipping Address (House No, Street, Landmark)"
                value={formData.address}
                onChange={handleChange}
                required
                className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  id="city"
                  placeholder="City"
                  value={formData.city}
                  onChange={handleChange}
                  required
                  className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
                />
                <input
                  type="text"
                  id="pincode"
                  placeholder="Pincode (6 digits)"
                  value={formData.pincode}
                  onChange={handleChange}
                  required
                  pattern="[0-9]{6}"
                  className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">
                  State
                </label>
                <select
                  id="state"
                  value={formData.state}
                  onChange={handleChange}
                  required
                  className="w-full p-3 bg-gray-50 rounded-xl outline-none border border-gray-200 focus:border-punjab transition-all text-sm cursor-pointer"
                >
                  {indianStates.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Order Summary Box */}
            <div className="bg-punjab-cream/50 p-6 rounded-2xl mb-8 border border-punjab-gold/10">
              <h4 className="font-serif font-bold text-punjab-soil mb-4">Order Summary</h4>
              <div className="space-y-2 mb-4 text-sm text-gray-700">
                {cartItems.length === 0 ? (
                  <p className="italic text-gray-500">Harvest Box is empty</p>
                ) : (
                  cartItems.map((item) => (
                    <div
                      key={item.cartId}
                      className="flex justify-between border-b border-punjab-gold/5 pb-2"
                    >
                      <span>
                        {item.product.name}
                        {item.variantUnit ? ` (${item.variantUnit})` : ''} x {item.quantity}
                      </span>
                      <span className="font-bold">₹{item.price * item.quantity}</span>
                    </div>
                  ))
                )}
              </div>

              <div className="space-y-2 pt-4 border-t border-punjab-gold/10">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span>₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Estimated Shipping</span>
                  <span>₹{shippingCost}</span>
                </div>
                <p className="text-[10px] text-gray-500 italic mt-1 leading-tight">
                  Final shipping charges will be confirmed after address verification.
                </p>
                <div className="flex justify-between font-bold text-xl pt-4 border-t border-punjab-gold/20 mt-2">
                  <span className="text-gray-800">Amount Payable Now</span>
                  <span className="text-punjab-dark">₹{totalPayable}</span>
                </div>
              </div>
            </div>

            {/* WhatsApp Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || cartItems.length === 0}
              className={`w-full py-4 rounded-xl font-bold shadow-lg transition-all transform flex items-center justify-center gap-2 ${
                isSubmitting || cartItems.length === 0
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-[#25D366] hover:bg-green-600 text-white hover:scale-[1.02] cursor-pointer'
              }`}
            >
              {isSubmitting ? (
                'Redirecting to WhatsApp...'
              ) : (
                <>
                  Confirm order via WhatsApp <MessageCircle className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
