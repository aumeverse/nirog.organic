﻿'use client';

import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { ProductCard } from './ProductCard';
import { PageView } from '@/types';

interface BestsellersSectionProps {
  onNavigate: (view: PageView) => void;
}

export const BestsellersSection: React.FC<BestsellersSectionProps> = ({ onNavigate }) => {
  const { products } = useProducts();
  const bestsellers = products.filter(p => p.isBestseller);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerView, setItemsPerView] = useState(4);
  const [isHovered, setIsHovered] = useState(false);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      let count = 4;
      if (w < 640) count = 1;
      else if (w < 1024) count = 2;
      else if (w < 1280) count = 3;
      else count = 4;

      setItemsPerView(count);
      const newMax = Math.max(0, bestsellers.length - count);
      setCurrentIndex(prev => Math.min(prev, newMax));
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [bestsellers.length]);

  const maxIndex = Math.max(0, bestsellers.length - itemsPerView);

  useEffect(() => {
    if (isHovered || maxIndex <= 0) return;
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
    }, 4000);
    return () => clearInterval(interval);
  }, [isHovered, maxIndex]);

  const handlePrev = () => {
    setCurrentIndex(prev => (prev <= 0 ? maxIndex : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const deltaX = e.changedTouches[0].clientX - touchStartX.current;
    if (deltaX > 50) handlePrev();
    else if (deltaX < -50) handleNext();
    touchStartX.current = null;
  };

  const itemWidthPercent = 100 / itemsPerView;

  if (bestsellers.length === 0) return null;

  return (
    <section id="bestsellers-section" className="py-24 bg-punjab-cream overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-end mb-12">
          <div>
            <span className="text-punjab-gold font-bold uppercase tracking-widest text-xs">
              Curated Selection
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-punjab-soil">
              Community Favorites
            </h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handlePrev}
              className="bestseller-prev bg-white p-3 rounded-full hover:bg-punjab hover:text-white transition-colors cursor-pointer shadow-sm"
              aria-label="Previous slide"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="bestseller-next bg-white p-3 rounded-full hover:bg-punjab hover:text-white transition-colors cursor-pointer shadow-sm"
              aria-label="Next slide"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div
          className="relative overflow-hidden pb-12 px-2"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          <div
            className="flex transition-transform duration-500 ease-out"
            style={{
              transform: `translateX(-${currentIndex * itemWidthPercent}%)`
            }}
          >
            {bestsellers.map((product) => (
              <div
                key={product.id}
                className="w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 flex-shrink-0 px-2.5 box-border"
              >
                <ProductCard
                  product={product}
                  type="bestseller"
                  onNavigate={onNavigate}
                />
              </div>
            ))}
          </div>

          <div className="flex justify-center items-center gap-2 mt-8">
            {Array.from({ length: maxIndex + 1 }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === currentIndex ? 'w-8 bg-punjab' : 'w-2.5 bg-gray-300 hover:bg-gray-400'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
