@echo off
title Nirog Organic Website
echo ===================================================
echo Opening Nirog Organic Website in your browser...
echo ===================================================
start "" "%~dp0out\index.html"
