﻿'use client';

import React, { useState } from 'react';
import { Plus, Trash2, Video, ExternalLink, Play, Check, AlertCircle } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { useCart } from '@/context/CartContext';
import { VideoItem } from '@/types';
import { resolveVideoEmbed } from '@/components/AboutReelSection';

export const VideosManagerTab: React.FC = () => {
  const { storeSettings, addVideo, updateVideo, deleteVideo } = useProducts();
  const { showToast } = useCart();
  const { videos } = storeSettings;

  // New video form state
  const [isAdding, setIsAdding] = useState(false);
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [error, setError] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Please provide a valid video URL');
      return;
    }

    const newVid: VideoItem = {
      id: 'vid_' + Date.now(),
      title: title.trim() || 'Heritage Farm Video',
      url: url.trim(),
      caption: caption.trim() || undefined
    };

    addVideo(newVid);
    showToast('Video added to homepage showcase!');
    setUrl('');
    setTitle('');
    setCaption('');
    setError('');
    setIsAdding(false);
  };

  const handleDelete = (id: string, vTitle: string) => {
    if (confirm(`Remove video "${vTitle}" from the homepage?`)) {
      deleteVideo(id);
      showToast('Video removed');
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header Box */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-punjab/10 text-punjab flex items-center justify-center">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-2xl font-bold text-punjab-soil">
                Homepage Video & Reel Showcase
              </h3>
              <p className="text-xs text-gray-500 mt-0.5">
                Add, preview, and manage Instagram Reels, YouTube Shorts, YouTube Videos, or direct MP4 videos.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsAdding(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-xs font-bold shadow-md transition-all hover:scale-[1.01] cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" /> Add Video URL
        </button>
      </div>

      {/* Add Video Modal / Drawer */}
      {isAdding && (
        <div className="bg-punjab-wheat/40 rounded-3xl p-6 sm:p-8 border border-punjab-gold/40 shadow-md animate-fade-in-up">
          <div className="flex items-center justify-between pb-4 border-b border-punjab-gold/20 mb-6">
            <h4 className="font-serif text-lg font-bold text-punjab-soil">
              Add New Video to Homepage
            </h4>
            <button
              onClick={() => setIsAdding(false)}
              className="text-xs text-gray-500 hover:text-gray-800 font-bold cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl mb-4 font-semibold">
              {error}
            </div>
          )}

          <form onSubmit={handleAddSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                Video URL * (Instagram Reel, YouTube Short, YouTube, or direct MP4)
              </label>
              <input
                type="url"
                required
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="e.g. https://www.instagram.com/reel/DUV0w0tj8Ib/ or https://youtube.com/shorts/..."
                className="w-full p-3 bg-white border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab font-mono"
              />
              <p className="text-[11px] text-gray-500 mt-1">
                Supports: <code className="text-punjab font-bold">instagram.com/reel/...</code>, <code className="text-punjab font-bold">youtube.com/shorts/...</code>, <code className="text-punjab font-bold">youtu.be/...</code>, and <code className="text-punjab font-bold">.mp4</code> URLs.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Video Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Stone-Ground Milling Process"
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Caption / Description
                </label>
                <input
                  type="text"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="e.g. 100% whole grain milling preserving germ & bran"
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab"
                />
              </div>
            </div>

            {/* URL Live Preview Card */}
            {url && (
              <div className="p-4 bg-white rounded-2xl border border-gray-200 mt-4">
                <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-punjab" /> Live Embed Preview
                </p>
                <div className="w-full max-w-[260px] h-[380px] rounded-xl overflow-hidden bg-black mx-auto shadow-inner">
                  {resolveVideoEmbed(url).type === 'video' ? (
                    <video
                      src={resolveVideoEmbed(url).embedUrl}
                      controls
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <iframe
                      src={resolveVideoEmbed(url).embedUrl}
                      className="w-full h-full border-none"
                      scrolling="no"
                      allow="autoplay; encrypted-media; picture-in-picture"
                      title="Preview"
                    />
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-5 py-2.5 rounded-xl border border-gray-300 text-gray-700 text-xs font-bold hover:bg-gray-100 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-xs font-bold shadow-md transition-all hover:scale-[1.01] cursor-pointer"
              >
                Confirm & Add to Homepage
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Videos List */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm">
        <h4 className="font-serif text-lg font-bold text-punjab-soil mb-4">
          Current Homepage Videos ({videos.length})
        </h4>

        {videos.length === 0 ? (
          <div className="py-12 text-center text-gray-400 text-xs">
            No videos currently configured for the homepage. Click &quot;Add Video URL&quot; above to add one.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((v) => {
              const { type, embedUrl } = resolveVideoEmbed(v.url);

              return (
                <div
                  key={v.id}
                  className="bg-gray-50 rounded-2xl p-4 border border-gray-200 flex flex-col justify-between hover:border-punjab transition-all"
                >
                  <div className="w-full h-[360px] rounded-xl overflow-hidden bg-black mb-3 shadow-inner">
                    {type === 'video' ? (
                      <video
                        src={embedUrl}
                        controls
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <iframe
                        src={embedUrl}
                        className="w-full h-full border-none"
                        scrolling="no"
                        allow="autoplay; encrypted-media; picture-in-picture"
                        title={v.title}
                      />
                    )}
                  </div>

                  <div>
                    <h5 className="font-bold text-gray-900 text-sm">{v.title}</h5>
                    {v.caption && (
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{v.caption}</p>
                    )}
                    <a
                      href={v.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-punjab font-bold hover:underline mt-1 break-all"
                    >
                      <ExternalLink className="w-3 h-3" /> {v.url.slice(0, 35)}...
                    </a>
                  </div>

                  <div className="pt-3 mt-3 border-t border-gray-200 flex justify-end">
                    <button
                      onClick={() => handleDelete(v.id, v.title)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
