﻿'use client';

import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Image as ImageIcon, Sparkles, Star, Check } from 'lucide-react';
import { Product, Variant } from '@/types';

interface ProductEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: Product) => void;
  product?: Product | null;
}

const CATEGORIES: Product['category'][] = [
  'Flours',
  'Oils',
  'Heritage Flours',
  'Spices',
  'Sweeteners',
  'Grains',
  'Gift Cards'
];

export const ProductEditModal: React.FC<ProductEditModalProps> = ({
  isOpen,
  onClose,
  onSave,
  product
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Product['category']>('Flours');
  const [price, setPrice] = useState<number>(0);
  const [unit, setUnit] = useState('');
  const [description, setDescription] = useState('');
  const [isBestseller, setIsBestseller] = useState(false);
  const [isOutOfStock, setIsOutOfStock] = useState(false);

  // Multiple Images State
  const [images, setImages] = useState<string[]>([]);
  const [newImageUrl, setNewImageUrl] = useState('');

  // Benefits & Variants
  const [benefits, setBenefits] = useState<string[]>([]);
  const [newBenefit, setNewBenefit] = useState('');
  const [variants, setVariants] = useState<Variant[]>([]);
  const [newVariantUnit, setNewVariantUnit] = useState('');
  const [newVariantPrice, setNewVariantPrice] = useState<number | ''>('');

  useEffect(() => {
    if (product) {
      setName(product.name || '');
      setCategory(product.category || 'Flours');
      setPrice(product.price || 0);
      setUnit(product.unit || '1 kg');
      setDescription(product.description || '');
      setIsBestseller(!!product.isBestseller);
      setIsOutOfStock(!!product.isOutOfStock);
      setBenefits(product.benefits ? [...product.benefits] : []);
      setVariants(product.variants ? [...product.variants] : []);

      // Load all images
      const initialImages =
        product.images && product.images.length > 0
          ? [...product.images]
          : product.img1
          ? [product.img1]
          : [];
      setImages(initialImages);
    } else {
      setName('');
      setCategory('Flours');
      setPrice(299);
      setUnit('1 kg');
      setDescription('100% pure organic certified direct from Punjab heritage farms.');
      setIsBestseller(false);
      setIsOutOfStock(false);
      setBenefits(['100% Certified Organic', 'Stone-ground heritage milling', 'Chemical & preservative free']);
      setVariants([]);
      setImages([
        'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=800'
      ]);
    }
    setNewImageUrl('');
  }, [product, isOpen]);

  if (!isOpen) return null;

  // Multiple Images Handlers
  const handleAddImage = () => {
    const trimmed = newImageUrl.trim();
    if (!trimmed) return;
    if (images.includes(trimmed)) {
      alert('This image URL is already in the list.');
      return;
    }
    setImages([...images, trimmed]);
    setNewImageUrl('');
  };

  const handleRemoveImage = (index: number) => {
    if (images.length <= 1) {
      alert('A product must have at least one image.');
      return;
    }
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSetPrimary = (index: number) => {
    if (index === 0) return;
    const selected = images[index];
    const filtered = images.filter((_, i) => i !== index);
    setImages([selected, ...filtered]);
  };

  // Benefits Handlers
  const handleAddBenefit = () => {
    if (!newBenefit.trim()) return;
    setBenefits([...benefits, newBenefit.trim()]);
    setNewBenefit('');
  };

  const handleRemoveBenefit = (index: number) => {
    setBenefits(benefits.filter((_, i) => i !== index));
  };

  // Variants Handlers
  const handleAddVariant = () => {
    if (!newVariantUnit.trim() || !newVariantPrice || Number(newVariantPrice) <= 0) return;
    setVariants([...variants, { u: newVariantUnit.trim(), p: Number(newVariantPrice) }]);
    setNewVariantUnit('');
    setNewVariantPrice('');
  };

  const handleRemoveVariant = (index: number) => {
    setVariants(variants.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || price <= 0 || !unit.trim() || images.length === 0) {
      alert('Please fill all required fields (Name, Price, Base Unit, at least 1 Image)');
      return;
    }

    const savedProduct: Product = {
      id: product?.id || ('prod_' + Date.now()),
      name: name.trim(),
      category,
      price: Number(price),
      unit: unit.trim(),
      img1: images[0],
      images: images,
      description: description.trim(),
      benefits: benefits.length > 0 ? benefits : ['100% Certified Organic'],
      variants: variants.length > 0 ? variants : undefined,
      isBestseller,
      isOutOfStock
    };

    onSave(savedProduct);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-punjab-cream rounded-3xl p-6 sm:p-8 shadow-2xl border border-punjab-gold/20 animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-punjab-gold/20 mb-6">
          <div>
            <h2 className="font-serif text-2xl font-bold text-punjab-soil">
              {product ? 'Edit Product Details' : 'Add New Heritage Product'}
            </h2>
            <p className="text-xs text-gray-500">
              {product ? `Updating #${product.id}` : 'Create a new item visible to all customers instantly'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Main Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sharbati Wheat Flour (100% Stone-Ground)"
                className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Product['category'])}
                className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Base Price (₹) *
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab"
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Base Unit *
                </label>
                <input
                  type="text"
                  required
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="1 kg / 500 ml"
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Product Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Share heritage farming origin, stone-ground milling details, or nutritional highlights..."
              className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:border-punjab"
            />
          </div>

          {/* MULTIPLE IMAGES SECTION */}
          <div className="p-5 bg-white rounded-2xl border border-gray-200 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700">
                  Product Photos & Gallery ({images.length} Image{images.length !== 1 ? 's' : ''})
                </label>
                <p className="text-[11px] text-gray-500">
                  Add multiple angles, packaging views, or nutrition photos. First photo is used as the Cover image.
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-punjab/10 text-punjab border border-punjab/20">
                Multi-Image Support
              </span>
            </div>

            {/* Input to add another image URL */}
            <div className="flex gap-2">
              <input
                type="url"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddImage();
                  }
                }}
                placeholder="Paste Image URL (https://images.unsplash.com/...)"
                className="flex-1 p-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-mono outline-none focus:border-punjab focus:bg-white"
              />
              <button
                type="button"
                onClick={handleAddImage}
                className="px-4 py-2.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer flex-shrink-0"
              >
                <Plus className="w-3.5 h-3.5" /> Add Image
              </button>
            </div>

            {/* Gallery Thumbnail Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {images.map((imgUrl, idx) => (
                <div
                  key={idx}
                  className={`relative group rounded-xl overflow-hidden border-2 bg-gray-100 flex flex-col items-center shadow-xs transition-all ${
                    idx === 0 ? 'border-punjab ring-2 ring-punjab/20' : 'border-gray-200 hover:border-punjab-gold'
                  }`}
                >
                  <div className="w-full h-28 relative">
                    <img
                      src={imgUrl}
                      alt={`Photo ${idx + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLElement).setAttribute(
                          'src',
                          'https://placehold.co/300x300/F0E6D8/854D0E?text=Photo'
                        );
                      }}
                    />

                    {/* Cover Photo Badge on first image */}
                    {idx === 0 ? (
                      <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-punjab text-white shadow-sm flex items-center gap-1">
                        <Star className="w-2.5 h-2.5 fill-white" /> Cover
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleSetPrimary(idx)}
                        className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full text-[9px] font-bold bg-black/60 hover:bg-punjab text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        title="Set as Cover photo"
                      >
                        Set Cover
                      </button>
                    )}

                    {/* Delete Photo Button */}
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1.5 right-1.5 p-1 rounded-full bg-red-600/80 hover:bg-red-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-sm"
                      title="Remove Photo"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="text-[10px] text-gray-500 py-1 font-mono">
                    #{idx + 1}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Toggles: Bestseller & In Stock */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-white/70 rounded-2xl border border-gray-200">
            <label className="flex items-center gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isBestseller}
                onChange={(e) => setIsBestseller(e.target.checked)}
                className="w-5 h-5 text-punjab rounded accent-punjab cursor-pointer"
              />
              <div>
                <span className="text-sm font-bold text-gray-800 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-punjab-gold" /> Feature in Bestsellers
                </span>
                <p className="text-[11px] text-gray-500">Display in the top curated favorites rail</p>
              </div>
            </label>

            <label className="flex items-center gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isOutOfStock}
                onChange={(e) => setIsOutOfStock(e.target.checked)}
                className="w-5 h-5 text-red-600 rounded accent-red-600 cursor-pointer"
              />
              <div>
                <span className="text-sm font-bold text-gray-800">
                  Mark as Out of Stock
                </span>
                <p className="text-[11px] text-gray-500">Disable Add-to-Cart buttons for customers</p>
              </div>
            </label>
          </div>

          {/* Key Benefits List */}
          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Product Benefits (Highlights)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newBenefit}
                onChange={(e) => setNewBenefit(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddBenefit();
                  }
                }}
                placeholder="e.g. Rich in natural wheat germ & bran"
                className="flex-1 p-2.5 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:border-punjab"
              />
              <button
                type="button"
                onClick={handleAddBenefit}
                className="px-4 py-2.5 bg-punjab-wheat border border-punjab-gold/40 text-punjab-soil font-bold text-xs rounded-xl hover:bg-punjab-gold hover:text-white transition-all cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {benefits.map((b, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-punjab/20 text-punjab-soil rounded-lg text-xs font-medium"
                >
                  {b}
                  <button
                    type="button"
                    onClick={() => handleRemoveBenefit(idx)}
                    className="text-gray-400 hover:text-red-500 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Size / Weight Variants */}
          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Size & Packaging Variants (Optional)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newVariantUnit}
                onChange={(e) => setNewVariantUnit(e.target.value)}
                placeholder="Unit: 5 kg or 5 L"
                className="w-1/2 p-2.5 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:border-punjab"
              />
              <input
                type="number"
                value={newVariantPrice}
                onChange={(e) => setNewVariantPrice(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Price ₹ (e.g. 799)"
                className="w-1/2 p-2.5 bg-white border border-gray-200 rounded-xl text-sm outline-none focus:border-punjab"
              />
              <button
                type="button"
                onClick={handleAddVariant}
                className="px-4 py-2.5 bg-punjab-wheat border border-punjab-gold/40 text-punjab-soil font-bold text-xs rounded-xl hover:bg-punjab-gold hover:text-white transition-all cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            {variants.length > 0 && (
              <div className="space-y-1.5">
                {variants.map((v, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2.5 bg-white border border-gray-200 rounded-xl text-xs font-medium"
                  >
                    <span><strong>{v.u}</strong> — ₹{v.p}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveVariant(idx)}
                      className="text-red-500 hover:text-red-700 cursor-pointer p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t border-punjab-gold/20">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold text-sm rounded-xl cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-8 py-3 bg-punjab hover:bg-punjab-dark text-white font-bold text-sm rounded-xl shadow-lg transition-all hover:scale-[1.01] cursor-pointer"
            >
              {product ? 'Update Product' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
