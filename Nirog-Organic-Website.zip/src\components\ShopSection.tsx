﻿'use client';

import React, { useState } from 'react';
import { useProducts } from '@/context/ProductContext';
import { ProductCard } from './ProductCard';
import { CategoryFilter } from '@/types';

const categories: { key: CategoryFilter; label: string }[] = [
  { key: 'All', label: 'All' },
  { key: 'Flours', label: 'Flours' },
  { key: 'Oils', label: 'Oils' },
  { key: 'Heritage Flours', label: 'Ancient Flours' },
  { key: 'Spices', label: 'Spices' },
  { key: 'Sweeteners', label: 'Sweeteners' },
];

export const ShopSection: React.FC = () => {
  const { products } = useProducts();
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>('All');

  const filteredProducts = activeCategory === 'All'
    ? products
    : products.filter(p => p.category === activeCategory);

  const handleFilter = (cat: CategoryFilter) => {
    setActiveCategory(cat);
    const topEl = document.getElementById('shop-top');
    if (topEl) {
      topEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="shop-top" className="pt-32 pb-24 bg-punjab-cream min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="font-serif text-4xl sm:text-5xl font-bold animated-header animate-header-pan-slow mb-2">
            The Punjab Pantry
          </h1>
          <p className="text-gray-500">{products.length} Premium Organic Products • 100% Traceable</p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 sticky top-24 z-30 bg-punjab-cream/90 backdrop-blur py-4">
          {categories.map(({ key, label }) => {
            const isActive = activeCategory === key;
            return (
              <button
                key={key}
                onClick={() => handleFilter(key)}
                className={`filter-btn px-6 py-2 rounded-full border transition-all cursor-pointer font-medium text-sm ${
                  isActive
                    ? 'border-punjab bg-punjab text-white'
                    : 'border-gray-300 bg-white text-punjab-dark hover:border-punjab'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* Product Grid */}
        <div
          id="product-grid"
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8"
        >
          {filteredProducts.map((p) => (
            <ProductCard key={p.id} product={p} type="shop" />
          ))}
        </div>
      </div>
    </div>
  );
};
