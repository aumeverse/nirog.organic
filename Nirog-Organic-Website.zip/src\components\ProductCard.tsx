﻿'use client';

import React, { useState } from 'react';
import { ShoppingCart, ArrowRight } from 'lucide-react';
import { Product, PageView } from '@/types';
import { useCart } from '@/context/CartContext';

interface ProductCardProps {
  product: Product;
  type?: 'shop' | 'bestseller';
  onNavigate?: (view: PageView) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  type = 'shop',
  onNavigate
}) => {
  const { cart, addToCart, updateQty, openModal } = useCart();

  const [selectedVariant, setSelectedVariant] = useState<string>(
    product.variants && product.variants.length > 0 ? product.variants[0].u : ''
  );
  const [inputQty, setInputQty] = useState<number>(1);

  const activeVariantObj = product.variants?.find(v => v.u === selectedVariant);
  const currentPrice = activeVariantObj ? activeVariantObj.p : product.price;
  const currentUnit = selectedVariant || product.unit;

  const cartKey = selectedVariant ? `${product.id}_${selectedVariant}` : product.id;
  const inCartQty = cart[cartKey] || 0;

  const isFlourGrainSweetener = ['Flours', 'Grains', 'Sweeteners', 'Heritage Flours'].includes(product.category);
  const unitLabel = isFlourGrainSweetener
    ? 'KG'
    : currentUnit && (currentUnit.includes('L') || currentUnit.includes('ml'))
    ? 'Unit'
    : 'pc';

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.isOutOfStock) return;
    addToCart(cartKey, inputQty);
  };

  const handleUpdateQty = (e: React.MouseEvent, delta: number) => {
    e.stopPropagation();
    updateQty(cartKey, delta);
  };

  const handleExploreMore = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onNavigate) {
      onNavigate('shop');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div
      onClick={() => openModal(product.id)}
      className="group bg-white rounded-3xl p-4 shadow-sm hover:shadow-float transition-all product-card-wrapper flex flex-col h-full cursor-pointer"
    >
      <div className="relative aspect-square rounded-2xl overflow-hidden mb-4 bg-punjab-cream">
        {product.isBestseller && (
          <span className="absolute top-2 left-2 z-10 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-md">
            BESTSELLER
          </span>
        )}
        {product.isOutOfStock && (
          <div className="absolute inset-0 bg-white/60 z-10 flex items-center justify-center font-bold text-gray-800 backdrop-blur-[2px]">
            OUT OF STOCK
          </div>
        )}
        {product.images && product.images.length > 1 && (
          <span className="absolute bottom-2 right-2 z-10 bg-black/60 text-white text-[10px] font-bold px-2 py-0.5 rounded-full backdrop-blur-xs flex items-center gap-1 shadow-sm">
            📷 {product.images.length}
          </span>
        )}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.img1}
          alt={product.name}
          className="w-full h-full object-cover transition-transform group-hover:scale-110"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://placehold.co/400x400/F0E6D8/854D0E?text=Product';
          }}
        />
      </div>

      <div className="px-1 flex flex-col flex-1">
        <span className="text-[10px] text-punjab uppercase font-bold tracking-widest">
          {product.category}
        </span>
        <h3 className="font-serif font-bold text-lg leading-tight mb-2 line-clamp-1 text-gray-900">
          {product.name}
        </h3>
        <div className="flex items-baseline gap-1 mb-2">
          <span className="text-xl font-bold text-punjab-dark">₹{currentPrice}</span>
          <span className="text-xs text-gray-400">/ {currentUnit}</span>
        </div>

        {type === 'shop' && product.variants && inCartQty === 0 && !product.isOutOfStock && (
          <div className="mb-2" onClick={(e) => e.stopPropagation()}>
            <select
              value={selectedVariant}
              onChange={(e) => setSelectedVariant(e.target.value)}
              className="w-full p-2 bg-gray-50 border border-gray-200 rounded text-xs font-bold text-gray-700 outline-none cursor-pointer"
            >
              {product.variants.map((v) => (
                <option key={v.u} value={v.u}>
                  {v.u} - ₹{v.p}
                </option>
              ))}
            </select>
          </div>
        )}

        {type === 'shop' && inCartQty === 0 && !product.isOutOfStock && (
          <div className="flex items-center justify-between mb-4 px-1" onClick={(e) => e.stopPropagation()}>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">
              Select Qty:
            </span>
            <div className="flex items-center h-8 bg-gray-50 rounded border border-gray-200 overflow-hidden">
              <input
                type="number"
                min={1}
                value={inputQty}
                onChange={(e) => setInputQty(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-12 h-full text-center text-sm font-bold bg-transparent outline-none"
              />
              <span className="px-2 text-[10px] font-bold text-gray-500 border-l border-gray-200 h-full flex items-center">
                {unitLabel}
              </span>
            </div>
          </div>
        )}

        <div className="mt-auto pt-2">
          {product.isOutOfStock ? (
            <div className="w-full py-3 bg-gray-200 text-gray-500 rounded-xl font-bold flex items-center justify-center gap-2 cursor-not-allowed uppercase text-xs">
              Out of Stock
            </div>
          ) : type === 'bestseller' ? (
            <button
              onClick={handleExploreMore}
              className="w-full py-3 bg-punjab-cream text-punjab-dark rounded-xl hover:bg-punjab hover:text-white transition-colors font-medium flex items-center justify-center gap-2 cursor-pointer"
            >
              Explore More <ArrowRight className="w-4 h-4" />
            </button>
          ) : inCartQty > 0 ? (
            <div
              className="flex items-center justify-between bg-punjab-cream rounded-xl p-1"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={(e) => handleUpdateQty(e, -1)}
                className="w-10 h-10 flex items-center justify-center text-punjab-dark hover:bg-white rounded-lg transition-all font-bold text-lg cursor-pointer"
                aria-label="Decrease quantity"
              >
                -
              </button>
              <span className="font-bold text-punjab-dark text-lg">{inCartQty}</span>
              <button
                onClick={(e) => handleUpdateQty(e, 1)}
                className="w-10 h-10 flex items-center justify-center text-punjab-dark hover:bg-white rounded-lg transition-all font-bold text-lg cursor-pointer"
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
          ) : (
            <button
              onClick={handleAddToCart}
              className="w-full py-3 bg-punjab-cream text-punjab-dark rounded-xl hover:bg-punjab hover:text-white transition-colors font-medium flex items-center justify-center gap-2 cursor-pointer"
            >
              Add to Cart <ShoppingCart className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
