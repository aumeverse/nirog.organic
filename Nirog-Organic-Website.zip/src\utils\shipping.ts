﻿import { ShippingConfig } from '@/types';

export const defaultShippingConfig: ShippingConfig = {
  punjab: {
    tier1: 49,
    tier2: 79,
    tier3: 94,
    tier4: 149,
    tier5: 149,
  },
  restOfIndia: {
    tier1: 69,
    tier2: 89,
    tier3: 129,
    tier4: 149,
    tier5: 169,
  },
};

export function parseWeightInKg(unitStr: string): number {
  if (!unitStr) return 0;
  const str = unitStr.toLowerCase();
  if (str.includes('ml')) return (parseFloat(str) || 0) / 1000;
  if (str.includes('l')) return parseFloat(str) || 0;
  if (str.includes('kg')) return parseFloat(str) || 0;
  if (str.includes('gm') || str.endsWith('g')) return (parseFloat(str) || 0) / 1000;
  return 0;
}

export function calculateShipping(
  weight: number,
  state: string,
  config: ShippingConfig = defaultShippingConfig
): number {
  if (weight <= 0) return 0;
  const isPunjab = state === "Punjab";
  const rates = isPunjab ? config.punjab : config.restOfIndia;

  if (weight <= 1) return rates.tier1;
  if (weight <= 5) return rates.tier2;
  if (weight <= 10) return rates.tier3;
  if (weight <= 20) return rates.tier4;
  return rates.tier5;
}
