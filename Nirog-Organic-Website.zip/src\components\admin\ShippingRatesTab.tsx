﻿'use client';

import React, { useState } from 'react';
import { Truck, RotateCcw, Check, Info } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { useCart } from '@/context/CartContext';
import { ShippingConfig } from '@/types';

export const ShippingRatesTab: React.FC = () => {
  const { shippingConfig, updateShippingConfig, resetShippingConfig } = useProducts();
  const { showToast } = useCart();
  const [config, setConfig] = useState<ShippingConfig>(shippingConfig);
  const [isSaved, setIsSaved] = useState(false);

  const handlePunjabChange = (tier: keyof ShippingConfig['punjab'], val: number) => {
    setConfig(prev => ({
      ...prev,
      punjab: {
        ...prev.punjab,
        [tier]: val
      }
    }));
    setIsSaved(false);
  };

  const handleRestChange = (tier: keyof ShippingConfig['restOfIndia'], val: number) => {
    setConfig(prev => ({
      ...prev,
      restOfIndia: {
        ...prev.restOfIndia,
        [tier]: val
      }
    }));
    setIsSaved(false);
  };

  const handleSave = () => {
    updateShippingConfig(config);
    setIsSaved(true);
    showToast('Shipping rates saved successfully!');
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset shipping rates to factory defaults?')) {
      resetShippingConfig();
      // Reload from context
      setTimeout(() => {
        window.location.reload();
      }, 300);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Intro info box */}
      <div className="bg-punjab-wheat/40 border border-punjab-gold/30 rounded-2xl p-5 flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-punjab/10 text-punjab flex items-center justify-center flex-shrink-0 mt-0.5">
          <Truck className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-bold text-punjab-soil text-base">Weight-Based Dynamic Shipping Rates</h3>
          <p className="text-xs text-gray-600 mt-1 leading-relaxed">
            The checkout engine calculates the total weight of stone-ground flours, cold-pressed oils, and spices in the customer cart, checks the delivery destination state, and automatically applies the tiered flat rate configured below.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Punjab Rates */}
        <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-5">
            <div>
              <span className="inline-block px-2.5 py-1 bg-punjab/10 text-punjab text-xs font-bold rounded-lg mb-1">
                Zone A
              </span>
              <h4 className="font-serif text-xl font-bold text-punjab-soil">Punjab & Tri-City</h4>
              <p className="text-xs text-gray-500">Local delivery within Punjab, Chandigarh & Mohali</p>
            </div>
            <Truck className="w-8 h-8 text-punjab opacity-80" />
          </div>

          <div className="space-y-4">
            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 1 (Up to 1 kg)</span>
                <span className="text-gray-400 font-normal">Small pouches / samples</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.punjab.tier1}
                  onChange={(e) => handlePunjabChange('tier1', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 2 (1.1 kg to 5 kg)</span>
                <span className="text-gray-400 font-normal">Standard 5kg flour bag</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.punjab.tier2}
                  onChange={(e) => handlePunjabChange('tier2', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 3 (5.1 kg to 10 kg)</span>
                <span className="text-gray-400 font-normal">Medium household pack</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.punjab.tier3}
                  onChange={(e) => handlePunjabChange('tier3', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 4 (10.1 kg to 20 kg)</span>
                <span className="text-gray-400 font-normal">Bulk family grocery</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.punjab.tier4}
                  onChange={(e) => handlePunjabChange('tier4', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 5 (Over 20 kg)</span>
                <span className="text-gray-400 font-normal">Commercial / Farm bulk</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.punjab.tier5}
                  onChange={(e) => handlePunjabChange('tier5', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Rest of India Rates */}
        <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-5">
            <div>
              <span className="inline-block px-2.5 py-1 bg-punjab-soil/10 text-punjab-soil text-xs font-bold rounded-lg mb-1">
                Zone B
              </span>
              <h4 className="font-serif text-xl font-bold text-punjab-soil">Rest of India</h4>
              <p className="text-xs text-gray-500">Pan-India express surface & air logistics</p>
            </div>
            <Truck className="w-8 h-8 text-punjab-soil opacity-80" />
          </div>

          <div className="space-y-4">
            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 1 (Up to 1 kg)</span>
                <span className="text-gray-400 font-normal">Small pouches / samples</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.restOfIndia.tier1}
                  onChange={(e) => handleRestChange('tier1', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 2 (1.1 kg to 5 kg)</span>
                <span className="text-gray-400 font-normal">Standard 5kg flour bag</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.restOfIndia.tier2}
                  onChange={(e) => handleRestChange('tier2', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 3 (5.1 kg to 10 kg)</span>
                <span className="text-gray-400 font-normal">Medium household pack</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.restOfIndia.tier3}
                  onChange={(e) => handleRestChange('tier3', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 4 (10.1 kg to 20 kg)</span>
                <span className="text-gray-400 font-normal">Bulk family grocery</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.restOfIndia.tier4}
                  onChange={(e) => handleRestChange('tier4', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-xs font-bold text-gray-700 mb-1">
                <span>Tier 5 (Over 20 kg)</span>
                <span className="text-gray-400 font-normal">Commercial / Farm bulk</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-sm">₹</span>
                <input
                  type="number"
                  min={0}
                  value={config.restOfIndia.tier5}
                  onChange={(e) => handleRestChange('tier5', Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-gray-200">
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-300 text-gray-600 hover:text-red-600 hover:border-red-200 text-xs font-bold transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" /> Reset Factory Defaults
        </button>

        <button
          type="button"
          onClick={handleSave}
          className="flex items-center gap-2 px-8 py-3 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-sm font-bold shadow-lg transition-all hover:scale-[1.01] cursor-pointer"
        >
          {isSaved ? <Check className="w-4 h-4" /> : null}
          {isSaved ? 'Rates Saved!' : 'Save Shipping Rates'}
        </button>
      </div>
    </div>
  );
};
