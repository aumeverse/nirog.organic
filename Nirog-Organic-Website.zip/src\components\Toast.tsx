﻿'use client';

import React, { useEffect, useState } from 'react';
import { useCart } from '@/context/CartContext';

export const Toast: React.FC = () => {
  const { toast } = useCart();
  const [messages, setMessages] = useState<{ id: number; text: string; isExiting: boolean }[]>([]);

  useEffect(() => {
    if (!toast) return;
    const id = Date.now();
    setMessages(prev => [...prev, { id, text: toast, isExiting: false }]);

    const exitTimer = setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === id ? { ...m, isExiting: true } : m));
    }, 2200);

    const removeTimer = setTimeout(() => {
      setMessages(prev => prev.filter(m => m.id !== id));
    }, 2600);

    return () => {
      clearTimeout(exitTimer);
      clearTimeout(removeTimer);
    };
  }, [toast]);

  return (
    <div id="toast-container" className="fixed top-24 right-0 z-50 p-4 max-w-xs pointer-events-none flex flex-col items-end">
      {messages.map((m) => (
        <div
          key={m.id}
          className={`bg-punjab text-white p-4 mb-3 rounded-xl shadow-lg border border-punjab-light/30 transition-all pointer-events-auto ${
            m.isExiting ? 'animate-toast-out' : 'animate-toast-in'
          }`}
        >
          {m.text}
        </div>
      ))}
    </div>
  );
};
