﻿'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';
import { PageView } from '@/types';
import { useProducts } from '@/context/ProductContext';

interface HeroSectionProps {
  onNavigate: (view: PageView) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate }) => {
  const { storeSettings } = useProducts();
  const { hero } = storeSettings;

  // Split headline for artistic styling if possible
  const headlineWords = hero.headline.split(' ');
  const firstPart = headlineWords.slice(0, -1).join(' ');
  const lastWord = headlineWords[headlineWords.length - 1] || '';

  return (
    <section id="hero-section" className="relative h-screen w-full flex items-center justify-center text-white">
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 z-10"
          style={{
            background: "linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.3)), url('https://images.unsplash.com/photo-1500382017468-9049fed747ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wzNjUyOXwwfDF8c2VhcmNofDEwfHx3aGVhdCUyMGZpZWelJTIwc3Vuc2V0fGVufDB8fHx8MTcwODY5MjYxN3ww&ixlib=rb-4.0.3&q=80&w=1920') no-repeat center center/cover"
          }}
        />
      </div>
      <div className="container mx-auto px-6 relative z-20 text-center mt-16">
        <h1 className="font-serif text-4xl sm:text-5xl md:text-8xl font-bold mb-6 leading-tight drop-shadow-2xl">
          {firstPart ? (
            <>
              {firstPart} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-punjab-gold to-yellow-200 italic">
                {lastWord}
              </span>
            </>
          ) : (
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-punjab-gold to-yellow-200 italic">
              {hero.headline}
            </span>
          )}
        </h1>

        <p className="text-base sm:text-lg md:text-xl text-gray-200 max-w-2xl mx-auto mb-4 font-light">
          {hero.subheadline}
        </p>

        {hero.tagline && (
          <p className="font-serif italic text-punjab-gold text-lg md:text-xl mb-6 tracking-wide drop-shadow-md">
            {hero.tagline}
          </p>
        )}

        <button
          onClick={() => onNavigate('shop')}
          className="inline-flex items-center px-10 py-4 bg-punjab-gold hover:bg-punjab hover:text-white text-punjab-soil rounded-full font-bold shadow-lg transition-all hover:scale-105 gap-2 cursor-pointer"
        >
          {hero.buttonText || 'View The Pantry'} <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
};
