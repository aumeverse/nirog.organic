﻿'use client';

import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Check, ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { useCart } from '@/context/CartContext';

export const ProductDetailModal: React.FC = () => {
  const { activeModalProduct, closeModal, addToCart } = useCart();
  const [selectedVariant, setSelectedVariant] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [qty, setQty] = useState<number>(1);

  useEffect(() => {
    if (activeModalProduct) {
      if (activeModalProduct.variants && activeModalProduct.variants.length > 0) {
        setSelectedVariant(activeModalProduct.variants[0].u);
      } else {
        setSelectedVariant('');
      }

      // Initialize selected image
      const allImgs =
        activeModalProduct.images && activeModalProduct.images.length > 0
          ? activeModalProduct.images
          : [activeModalProduct.img1];
      setSelectedImage(allImgs[0]);
      setQty(1);
    }
  }, [activeModalProduct]);

  if (!activeModalProduct) return null;

  const productImages =
    activeModalProduct.images && activeModalProduct.images.length > 0
      ? activeModalProduct.images
      : [activeModalProduct.img1];

  const activeVariantObj = activeModalProduct.variants?.find(v => v.u === selectedVariant);
  const currentPrice = activeVariantObj ? activeVariantObj.p : activeModalProduct.price;
  const currentUnit = selectedVariant || activeModalProduct.unit;

  const handleAdd = () => {
    if (activeModalProduct.isOutOfStock) return;
    const cid = selectedVariant ? `${activeModalProduct.id}_${selectedVariant}` : activeModalProduct.id;
    addToCart(cid, qty);
    closeModal();
  };

  const currentIndex = productImages.indexOf(selectedImage);

  const handlePrevImg = () => {
    const prevIdx = (currentIndex - 1 + productImages.length) % productImages.length;
    setSelectedImage(productImages[prevIdx]);
  };

  const handleNextImg = () => {
    const nextIdx = (currentIndex + 1) % productImages.length;
    setSelectedImage(productImages[nextIdx]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={closeModal}
      />
      <div className="relative z-10 w-full max-w-4xl max-h-[92vh] bg-punjab-cream rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row animate-fade-in-up">
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-4 right-4 z-30 bg-white/70 backdrop-blur-md p-2 rounded-full hover:bg-white transition-colors cursor-pointer shadow-md"
          aria-label="Close modal"
        >
          <X className="w-6 h-6 text-gray-700" />
        </button>

        {/* Left Column: Image & Multiple Thumbnails Gallery */}
        <div className="w-full md:w-1/2 bg-white flex flex-col justify-between p-4 sm:p-6 border-b md:border-b-0 md:border-r border-punjab-gold/20">
          {/* Main Display Image */}
          <div className="w-full h-64 sm:h-80 md:h-[420px] rounded-2xl overflow-hidden bg-gray-50 relative group flex items-center justify-center border border-gray-100">
            <img
              src={selectedImage || activeModalProduct.img1}
              alt={activeModalProduct.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://placehold.co/600x600/F0E6D8/854D0E?text=Product';
              }}
            />

            {/* Prev / Next Arrows if multiple images */}
            {productImages.length > 1 && (
              <>
                <button
                  onClick={handlePrevImg}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 hover:bg-white text-gray-800 shadow-md transition-all cursor-pointer opacity-80 hover:opacity-100"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextImg}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 hover:bg-white text-gray-800 shadow-md transition-all cursor-pointer opacity-80 hover:opacity-100"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <span className="absolute bottom-2 right-2 px-2.5 py-1 rounded-full text-[10px] font-bold bg-black/60 text-white backdrop-blur-xs">
                  {currentIndex + 1} / {productImages.length}
                </span>
              </>
            )}
          </div>

          {/* Multiple Thumbnails Strip */}
          {productImages.length > 1 && (
            <div className="flex gap-2.5 mt-4 overflow-x-auto pb-1">
              {productImages.map((imgUrl, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(imgUrl)}
                  className={`w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all cursor-pointer ${
                    selectedImage === imgUrl
                      ? 'border-punjab ring-2 ring-punjab/30 scale-105'
                      : 'border-gray-200 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={imgUrl}
                    alt={`Thumb ${i + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Details & Purchasing */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 md:p-10 overflow-y-auto flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase text-punjab tracking-widest block mb-1">
              {activeModalProduct.category}
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold mb-3 text-gray-900 leading-tight">
              {activeModalProduct.name}
            </h2>
            <p className="text-gray-600 mb-6 font-light text-xs sm:text-sm leading-relaxed">
              {activeModalProduct.description || "Pure heritage quality directly from Punjab's organic farms."}
            </p>

            {/* Benefits */}
            <div className="bg-white/60 p-4 sm:p-5 rounded-2xl border border-punjab-wheat mb-6 shadow-xs">
              <h4 className="font-bold flex items-center gap-2 mb-2.5 text-xs sm:text-sm text-gray-800 uppercase tracking-wide">
                <ShieldCheck className="w-4 h-4 text-punjab" /> Verified Heritage Benefits
              </h4>
              <ul className="space-y-1.5 text-xs sm:text-sm text-gray-600">
                {activeModalProduct.benefits.map((b, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-punjab flex-shrink-0" /> {b}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-200/80 pt-4 mt-auto">
            {activeModalProduct.variants && !activeModalProduct.isOutOfStock && (
              <div className="mb-4">
                <label className="text-xs font-bold uppercase text-gray-500 mb-2 block">
                  Choose Packaging Size
                </label>
                <select
                  value={selectedVariant}
                  onChange={(e) => setSelectedVariant(e.target.value)}
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-800 outline-none cursor-pointer focus:border-punjab"
                >
                  {activeModalProduct.variants.map((v) => (
                    <option key={v.u} value={v.u}>
                      {v.u} — ₹{v.p}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex justify-between items-center mb-5">
              <div>
                <span className="text-3xl font-bold text-punjab-dark">₹{currentPrice}</span>
                <span className="text-sm text-gray-400 ml-1">/ {currentUnit}</span>
              </div>

              {!activeModalProduct.isOutOfStock && (
                <div className="flex items-center bg-white rounded-full border border-gray-200 px-3.5 py-1 shadow-xs">
                  <button
                    onClick={() => setQty((prev) => Math.max(1, prev - 1))}
                    className="text-punjab hover:bg-gray-100 p-1 rounded-full text-base font-bold w-6 h-6 flex items-center justify-center cursor-pointer"
                  >
                    -
                  </button>
                  <span className="mx-3 font-bold text-gray-800 text-sm">{qty}</span>
                  <button
                    onClick={() => setQty((prev) => prev + 1)}
                    className="text-punjab hover:bg-gray-100 p-1 rounded-full text-base font-bold w-6 h-6 flex items-center justify-center cursor-pointer"
                  >
                    +
                  </button>
                </div>
              )}
            </div>

            {activeModalProduct.isOutOfStock ? (
              <button
                disabled
                className="w-full py-4 bg-gray-300 text-gray-500 rounded-xl font-bold shadow-sm cursor-not-allowed uppercase text-sm"
              >
                Out of Stock
              </button>
            ) : (
              <button
                onClick={handleAdd}
                className="w-full py-4 bg-punjab hover:bg-punjab-dark text-white rounded-xl font-bold shadow-lg transition-all hover:scale-[1.01] cursor-pointer text-sm sm:text-base"
              >
                Add to Harvest Box
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
