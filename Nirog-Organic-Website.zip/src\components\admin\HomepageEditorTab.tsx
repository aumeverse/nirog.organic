﻿'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  Flame,
  Layout,
  MessageCircle,
  Check,
  RotateCcw,
  Palette,
  Eye,
  ExternalLink
} from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { useCart } from '@/context/CartContext';
import { OfferBarColor } from '@/types';

export const HomepageEditorTab: React.FC = () => {
  const { storeSettings, updateOfferBar, updateHero, updateWhatsappNumber, resetStoreSettings } = useProducts();
  const { showToast } = useCart();

  // Local form state
  const [offerEnabled, setOfferEnabled] = useState(storeSettings.offerBar.enabled);
  const [offerColor, setOfferColor] = useState<OfferBarColor>(storeSettings.offerBar.color);
  const [offerHeadline, setOfferHeadline] = useState(storeSettings.offerBar.headline);
  const [offerDescription, setOfferDescription] = useState(storeSettings.offerBar.description);

  const [heroHeadline, setHeroHeadline] = useState(storeSettings.hero.headline);
  const [heroSubheadline, setHeroSubheadline] = useState(storeSettings.hero.subheadline);
  const [heroTagline, setHeroTagline] = useState(storeSettings.hero.tagline);
  const [heroButtonText, setHeroButtonText] = useState(storeSettings.hero.buttonText);

  const [whatsappPhone, setWhatsappPhone] = useState(storeSettings.whatsappNumber);

  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    updateOfferBar({
      enabled: offerEnabled,
      color: offerColor,
      headline: offerHeadline.trim(),
      description: offerDescription.trim()
    });

    updateHero({
      headline: heroHeadline.trim(),
      subheadline: heroSubheadline.trim(),
      tagline: heroTagline.trim(),
      buttonText: heroButtonText.trim()
    });

    updateWhatsappNumber(whatsappPhone.trim());

    setIsSaved(true);
    showToast('Homepage settings & offer notch updated successfully!');
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleReset = () => {
    if (confirm('Reset homepage hero texts, offer notch bar, and WhatsApp number to factory defaults?')) {
      resetStoreSettings();
      showToast('Restored default homepage settings');
      setTimeout(() => window.location.reload(), 300);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-8 animate-fade-in">
      {/* SECTION 1: OFFER NOTCH BAR */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-punjab-soil">
                Homepage Offer Notch Bar
              </h3>
              <p className="text-xs text-gray-500">
                A promotional notch displayed just below the floating navigation bar at the top of the homepage.
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={offerEnabled}
              onChange={(e) => setOfferEnabled(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-punjab"></div>
            <span className="ml-3 text-xs font-bold text-gray-700">
              {offerEnabled ? 'Active' : 'Disabled'}
            </span>
          </label>
        </div>

        {/* 3 Color Selector */}
        <div>
          <label className="block text-xs font-bold uppercase text-gray-700 mb-2 flex items-center gap-1.5">
            <Palette className="w-4 h-4 text-punjab" /> Notch Bar Color (Select 1 of 3)
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Red */}
            <div
              onClick={() => setOfferColor('red')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                offerColor === 'red'
                  ? 'border-red-600 bg-red-50/70 shadow-md ring-2 ring-red-500/20'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-red-700 uppercase tracking-wide">
                  Festival Red (Default)
                </span>
                {offerColor === 'red' && <Check className="w-4 h-4 text-red-600" />}
              </div>
              <div className="h-6 rounded-lg bg-gradient-to-r from-red-600 via-rose-600 to-red-700 shadow-xs" />
            </div>

            {/* Orange / Yellow */}
            <div
              onClick={() => setOfferColor('orange')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                offerColor === 'orange'
                  ? 'border-orange-500 bg-orange-50/70 shadow-md ring-2 ring-orange-500/20'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-amber-700 uppercase tracking-wide">
                  Harvest Orange / Gold
                </span>
                {offerColor === 'orange' && <Check className="w-4 h-4 text-amber-600" />}
              </div>
              <div className="h-6 rounded-lg bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 shadow-xs" />
            </div>

            {/* Green */}
            <div
              onClick={() => setOfferColor('green')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                offerColor === 'green'
                  ? 'border-green-600 bg-green-50/70 shadow-md ring-2 ring-green-500/20'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-xs text-green-700 uppercase tracking-wide">
                  Organic Emerald Green
                </span>
                {offerColor === 'green' && <Check className="w-4 h-4 text-green-600" />}
              </div>
              <div className="h-6 rounded-lg bg-gradient-to-r from-emerald-600 via-green-600 to-teal-700 shadow-xs" />
            </div>
          </div>
        </div>

        {/* Headline & Description */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Offer Headline *
            </label>
            <input
              type="text"
              required
              value={offerHeadline}
              onChange={(e) => setOfferHeadline(e.target.value)}
              placeholder="e.g. SPECIAL HARVEST OFFER: FLAT 15% OFF"
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold outline-none focus:border-punjab focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Offer Description / Coupon Code *
            </label>
            <input
              type="text"
              required
              value={offerDescription}
              onChange={(e) => setOfferDescription(e.target.value)}
              placeholder="e.g. Use code PUNJAB15 at checkout • Free shipping over ₹999"
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab focus:bg-white"
            />
          </div>
        </div>

        {/* Live Notch Preview */}
        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200">
          <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-punjab" /> Live Notch Preview (as seen by customers)
          </p>
          <div
            className={`rounded-full py-2 px-4 shadow-md flex items-center justify-between gap-3 overflow-hidden text-white ${
              offerColor === 'red'
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700'
                : offerColor === 'orange'
                ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600'
                : 'bg-gradient-to-r from-emerald-600 via-green-600 to-teal-700'
            }`}
          >
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/15 text-[10px] font-black uppercase tracking-wider flex-shrink-0">
              🔥 Special Offer
            </div>
            <div className="flex-1 overflow-hidden relative">
              <div className="animate-marquee-smooth flex items-center whitespace-nowrap">
                {[1, 2, 3].map((idx) => (
                  <div key={idx} className="flex items-center mx-3 gap-2 text-xs">
                    <strong className="tracking-wide uppercase">{offerHeadline || 'SPECIAL HARVEST OFFER'}</strong>
                    <span className="opacity-90">• {offerDescription || 'Free shipping on orders over ₹999'}</span>
                    <span className="px-2 py-0.5 rounded-full bg-white/25 text-[10px] font-extrabold">Shop Now &rarr;</span>
                    <span className="mx-2 text-yellow-300">✦</span>
                  </div>
                ))}
              </div>
            </div>
            <span className="px-3 py-1 bg-white text-gray-900 rounded-full text-[11px] font-extrabold shadow-xs flex-shrink-0">
              Shop Now
            </span>
          </div>
        </div>
      </div>

      {/* SECTION 2: HOMEPAGE HERO CONTENT */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <Layout className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif text-xl font-bold text-punjab-soil">
              Homepage Hero Section Content
            </h3>
            <p className="text-xs text-gray-500">
              Customize the main headline, sub-headline, tagline, and call-to-action button on the landing screen.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Main Headline *
            </label>
            <input
              type="text"
              required
              value={heroHeadline}
              onChange={(e) => setHeroHeadline(e.target.value)}
              placeholder="Punjab's Living Heritage"
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold outline-none focus:border-punjab focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
              Sub-Headline Description *
            </label>
            <textarea
              rows={2}
              required
              value={heroSubheadline}
              onChange={(e) => setHeroSubheadline(e.target.value)}
              placeholder="Slow stone-ground flours and woodpressed oils direct from the source."
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                Badge / Tagline
              </label>
              <input
                type="text"
                value={heroTagline}
                onChange={(e) => setHeroTagline(e.target.value)}
                placeholder="Premium Organic Products"
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                Primary CTA Button Text
              </label>
              <input
                type="text"
                value={heroButtonText}
                onChange={(e) => setHeroButtonText(e.target.value)}
                placeholder="View The Pantry"
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs outline-none focus:border-punjab focus:bg-white"
              />
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: WHATSAPP NUMBER REDIRECTION */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-4">
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
          <div className="w-10 h-10 rounded-xl bg-green-50 text-green-600 flex items-center justify-center">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif text-xl font-bold text-punjab-soil">
              WhatsApp Order & Support Routing Number
            </h3>
            <p className="text-xs text-gray-500">
              When a customer clicks Confirm Order via WhatsApp or the floating chat button, it opens a direct chat with this phone number.
            </p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
            WhatsApp Phone Number (with Country Code)
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-xs">+</span>
              <input
                type="text"
                required
                value={whatsappPhone}
                onChange={(e) => setWhatsappPhone(e.target.value)}
                placeholder="917009395451"
                className="w-full pl-8 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-mono font-bold outline-none focus:border-punjab focus:bg-white"
              />
            </div>
            <a
              href={`https://wa.me/${whatsappPhone.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1.5 px-5 py-3 rounded-xl bg-green-50 hover:bg-green-100 text-green-700 text-xs font-bold transition-colors cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" /> Test WhatsApp Link
            </a>
          </div>
          <p className="text-[11px] text-gray-500 mt-1.5">
            Include 91 for India without spaces or symbols (e.g. <code className="font-mono text-punjab font-bold">917009395451</code>).
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-gray-200">
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-300 text-gray-600 hover:text-red-600 hover:border-red-200 text-xs font-bold transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" /> Reset Factory Defaults
        </button>

        <button
          type="submit"
          className="flex items-center gap-2 px-8 py-3.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-sm font-bold shadow-lg transition-all hover:scale-[1.01] cursor-pointer"
        >
          {isSaved ? <Check className="w-4 h-4" /> : null}
          {isSaved ? 'Settings Saved!' : 'Save Homepage & Offer Settings'}
        </button>
      </div>
    </form>
  );
};
