﻿# 🌾 Nirog Organic — Punjab's Living Heritage

[![Next.js](https://img.shields.io/badge/Next.js-16.2.4-black?style=for-the-badge&logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19.1.0-blue?style=for-the-badge&logo=react)](https://react.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v4-38B2AC?style=for-the-badge&logo=tailwind-css)](https://tailwindcss.com/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178C6?style=for-the-badge&logo=typescript)](https://www.typescriptlang.org/)

A modern, high-performance e-commerce platform and administrative management portal built for **Nirog Organic**, reviving the authentic "Sanjha Chulha" culture with pure stone-ground flours, woodpressed oils, and farm-traceable heritage goods from 2,000+ certified organic farmers in Punjab.

---

## ✨ Features

### 🛒 Customer Experience
- **21 Heritage Organic Products**: Complete catalog with categories (Flours, Oils, Heritage Flours, Spices, Sweeteners, Grains).
- **Interactive Multi-Photo Gallery**: Full image modal with thumbnail switcher, multiple angle previews, and responsive zooming.
- **Smooth Left-Moving Offer Notch Bar**: Pinned right below the navigation bar with an infinite, silky-smooth marquee tape and hover-to-pause interaction.
- **"Why Choose Us" Luxury Conveyor**: Single continuous smooth-moving channel with dual-tone glowing organic icons and verified trust metrics.
- **Video & Reel Showcase**: Displays Instagram Reels, YouTube Shorts, YouTube videos, and direct MP4 videos.
- **Dynamic Weight-Based Tiered Shipping**: Automatic 5-bracket flat shipping calculation for both **Punjab & Tri-City** and **Rest of India**.
- **Interactive Cart Drawer & Instant Checkout**: Persistent cart state, live quantity adjustments, and WhatsApp order redirect.

### 🛡️ Administrative Management Portal ("Edmund Panel")
- **Authentication Protected**: Accessible via the footer link and protected with custom administrative credentials.
  - **Default Username:** `jagmindarsingh`
  - **Default Password:** `nirogorganic`
- **Product Catalog Management**: Add new products, edit descriptions, adjust prices, manage multi-photo galleries, set cover images, and instant 1-click toggles for *In Stock* and *Bestseller* status.
- **Offer Notch Configuration**: Choose between 3 vibrant themes (**Festival Red**, **Harvest Orange / Gold**, **Organic Emerald Green**), edit headlines and coupon codes with live preview.
- **Video Reels Manager**: Add and delete Instagram Reels, YouTube Shorts, or video links dynamically.
- **Tiered Shipping Rate Editor**: Real-time adjustment of shipping prices across 5 weight brackets.
- **Dynamic WhatsApp Order Routing**: Update the WhatsApp phone number to redirect orders and customer inquiries.
- **Security & Password Management**: Change administrative login credentials anytime.

---

## 🚀 Quick Start (Local Development)

### 1. Prerequisites
- **Node.js 18.x or higher** (Node.js 20 or 24 recommended)
- **npm**, **pnpm**, or **yarn**

### 2. Installation
```bash
# Clone repository
git clone https://github.com/your-username/nirog-organic.git
cd nirog-organic

# Install dependencies
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) with your browser.

### 4. Build for Production
```bash
npm run build
```
Generates an optimized static production export in the `./out` directory.

---

## 🌐 1-Click Deployments

### Deploy to Vercel (Recommended)
This repository is 100% pre-configured for Vercel:
1. Push this repository to GitHub.
2. Go to [vercel.com](https://vercel.com) and click **"Add New Project"**.
3. Select your repository and click **Deploy** (zero-config required).

### Deploy to GitHub Pages
A pre-configured GitHub Actions workflow is included at [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml):
1. Push to `main` or `master`.
2. In your GitHub repository settings, navigate to **Pages** &rarr; **Build and deployment** &rarr; **Source** and select **GitHub Actions**.
3. Every commit will automatically build and deploy the live static site to your GitHub Pages URL!

### Deploy to Netlify
1. Connect your GitHub repository to [netlify.com](https://netlify.com).
2. Build command: `npm run build`
3. Publish directory: `out`

---

## 📂 Project Structure
```
nirog-organic/
├── .github/
│   └── workflows/
│       └── deploy.yml          # Automated GitHub Pages CI/CD workflow
├── public/                     # Static media and assets
├── src/
│   ├── app/
│   │   ├── globals.css         # Tailwind v4 styles, container widths & smooth marquee keyframes
│   │   ├── layout.tsx          # Root HTML layout with Google Fonts & Context Providers
│   │   └── page.tsx            # Main page routing (Home, Shop, Checkout, Admin)
│   ├── components/
│   │   ├── admin/
│   │   │   ├── HomepageEditorTab.tsx   # Hero text, Offer Notch & WhatsApp settings
│   │   │   ├── ProductEditModal.tsx    # Add/Edit modal with multi-image gallery support
│   │   │   ├── ShippingRatesTab.tsx    # Dynamic weight-based tiered shipping editor
│   │   │   └── VideosManagerTab.tsx    # Instagram & YouTube video reels manager
│   │   ├── AboutReelSection.tsx        # Dynamic video showcase gallery
│   │   ├── AdminLoginModal.tsx         # Password-protected modal
│   │   ├── AdminPanel.tsx              # Admin dashboard layout & metric cards
│   │   ├── BestsellersSection.tsx      # Curated favorites carousel
│   │   ├── CartSidebar.tsx             # Interactive slide-over cart drawer
│   │   ├── CheckoutSection.tsx         # Weight-based checkout & WhatsApp order submission
│   │   ├── FloatingWhatsApp.tsx        # Dynamic floating WhatsApp button
│   │   ├── Footer.tsx                  # Footer with admin portal link
│   │   ├── Header.tsx                  # Floating navigation bar with live cart badge
│   │   ├── HeroSection.tsx             # Dynamic landing hero
│   │   ├── OfferNotchBar.tsx           # Pinned left-moving marquee offer notch
│   │   ├── ProductCard.tsx             # Product cards with photo count badges
│   │   ├── ProductDetailModal.tsx      # Interactive product modal with multi-image gallery
│   │   ├── ShopSection.tsx             # Filterable product grid
│   │   ├── SuccessModal.tsx            # Post-checkout order confirmation
│   │   └── WhyChooseUsSection.tsx      # Smooth left-moving luxury conveyor
│   ├── context/
│   │   ├── CartContext.tsx             # Cart state & local storage syncing
│   │   └── ProductContext.tsx          # Store settings, live products & authentication
│   ├── data/
│   │   └── products.ts                 # 21 default heritage products catalog
│   ├── types/
│   │   └── index.ts                    # TypeScript definitions
│   └── utils/
│       └── shipping.ts                 # Weight calculation & shipping tier resolution
├── next.config.ts                      # Static export and Next.js configuration
├── package.json                        # Scripts and dependencies
└── tsconfig.json                       # TypeScript compiler options
```

---

## 📜 License
MIT © Nirog Organic. Made with ❤️ in Punjab.
