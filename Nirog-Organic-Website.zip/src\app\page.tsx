﻿'use client';

import React, { useState, useEffect } from 'react';
import { PageView } from '@/types';
import { Header } from '@/components/Header';
import { HeroSection } from '@/components/HeroSection';
import { OfferNotchBar } from '@/components/OfferNotchBar';
import { JourneySection } from '@/components/JourneySection';
import { AboutReelSection } from '@/components/AboutReelSection';
import { BestsellersSection } from '@/components/BestsellersSection';
import { WhyChooseUsSection } from '@/components/WhyChooseUsSection';
import { ShopSection } from '@/components/ShopSection';
import { CheckoutSection } from '@/components/CheckoutSection';
import { AdminPanel } from '@/components/AdminPanel';
import { AdminLoginModal } from '@/components/AdminLoginModal';
import { CartSidebar } from '@/components/CartSidebar';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { SuccessModal } from '@/components/SuccessModal';
import { FloatingWhatsApp } from '@/components/FloatingWhatsApp';
import { Toast } from '@/components/Toast';
import { Footer } from '@/components/Footer';
import { useProducts } from '@/context/ProductContext';

export default function Home() {
  const [view, setView] = useState<PageView>('home');
  const { isAuthenticated, openLoginModal } = useProducts();

  useEffect(() => {
    const handleHash = () => {
      const h = window.location.hash.replace('#', '');
      if (h === 'shop' || h === 'checkout' || h === 'home') {
        setView(h as PageView);
      } else if (h === 'admin') {
        if (isAuthenticated) {
          setView('admin');
        } else {
          openLoginModal();
        }
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [isAuthenticated, openLoginModal]);

  const handleNavigate = (newView: PageView) => {
    if (newView === 'admin' && !isAuthenticated) {
      openLoginModal();
      return;
    }
    setView(newView);
    window.location.hash = newView;
  };

  return (
    <div className="min-h-screen flex flex-col justify-between">
      {/* Show header on customer views; on admin panel, AdminPanel has its own top header */}
      {view !== 'admin' && <Header currentView={view} setView={handleNavigate} />}

      <main className="flex-1">
        {view === 'home' && (
          <div id="page-home" className="page active">
            <OfferNotchBar onNavigate={handleNavigate} />
            <HeroSection onNavigate={handleNavigate} />
            <JourneySection />
            <AboutReelSection />
            <BestsellersSection onNavigate={handleNavigate} />
            <WhyChooseUsSection onNavigate={handleNavigate} />
          </div>
        )}

        {view === 'shop' && (
          <div id="page-shop" className="page active animate-product-fade-in">
            <ShopSection />
          </div>
        )}

        {view === 'checkout' && (
          <div id="page-checkout-wrapper" className="animate-fade-in-up">
            <CheckoutSection onNavigate={handleNavigate} />
          </div>
        )}

        {view === 'admin' && (
          <div id="page-admin-wrapper" className="animate-fade-in">
            {isAuthenticated ? (
              <AdminPanel onNavigate={handleNavigate} />
            ) : (
              <div className="pt-36 pb-24 text-center">
                <p className="text-gray-500 mb-4">Please log in to access the Admin Panel.</p>
                <button
                  onClick={openLoginModal}
                  className="px-6 py-2.5 bg-punjab text-white font-bold rounded-xl shadow-md cursor-pointer"
                >
                  Admin Login
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {view !== 'admin' && <Footer onNavigate={handleNavigate} />}

      {/* Global Modals & Overlays */}
      <AdminLoginModal onNavigate={handleNavigate} />
      <CartSidebar onNavigate={handleNavigate} />
      <ProductDetailModal />
      <SuccessModal />
      <FloatingWhatsApp />
      <Toast />
    </div>
  );
}
