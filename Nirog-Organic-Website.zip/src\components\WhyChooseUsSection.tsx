﻿'use client';

import React from 'react';
import {
  ShieldCheck,
  Droplets,
  Sprout,
  Award,
  Recycle,
  Sparkles,
  HeartHandshake,
  CheckCircle2
} from 'lucide-react';
import { PageView } from '@/types';

interface WhyChooseUsSectionProps {
  onNavigate: (view: PageView) => void;
}

const reasons = [
  {
    icon: Sparkles,
    badge: 'Heritage Milling',
    title: 'Stone-Ground Chakki',
    desc: 'Slow, low-temperature stone grinding that preserves 100% natural wheat germ, rich bran fibers, and essential B-vitamins.',
    highlight: 'Zero Heat Damage • Full Nutrition',
    iconColor: 'from-amber-400 to-yellow-500 text-soil shadow-amber-500/20'
  },
  {
    icon: ShieldCheck,
    badge: 'Chemical Free',
    title: 'Zero Preservatives',
    desc: 'Strictly unbleached, additive-free, and unrefined. What you taste is pure harvest directly from Punjab soil.',
    highlight: 'No Bleach • 0% Chemicals',
    iconColor: 'from-emerald-400 to-green-600 text-white shadow-emerald-500/20'
  },
  {
    icon: Droplets,
    badge: 'Kachhi Ghani',
    title: 'Cold-Pressed Under 40°C',
    desc: 'Extracted in traditional wooden kohlus without heat or chemical solvents, locking in natural antioxidants and heart-healthy omegas.',
    highlight: 'Pure Aroma • Unrefined',
    iconColor: 'from-yellow-400 to-amber-600 text-white shadow-yellow-500/20'
  },
  {
    icon: Sprout,
    badge: 'Direct Trade',
    title: 'Direct From 2,000+ Farmers',
    desc: 'Fair-trade partnerships with heritage Punjabi farming families. 100% traceable from seed to your kitchen pantry.',
    highlight: 'Farm-Gate Sourced • Ethical',
    iconColor: 'from-lime-400 to-emerald-500 text-white shadow-lime-500/20'
  },
  {
    icon: Award,
    badge: 'Generational Craft',
    title: 'Living Heritage Legacy',
    desc: 'Honoring the authentic "Sanjha Chulha" culture of Punjab with time-honored recipes trusted by generations.',
    highlight: 'Rooted in Tradition',
    iconColor: 'from-amber-300 to-orange-500 text-white shadow-amber-500/20'
  },
  {
    icon: Recycle,
    badge: 'Conscious Living',
    title: 'Eco-Minded Packaging',
    desc: 'Packed in breathable cotton and recyclable food-grade pouches designed to honor our soil and environment.',
    highlight: 'Plastic-Minimal • Sustainable',
    iconColor: 'from-teal-400 to-cyan-600 text-white shadow-teal-500/20'
  },
  {
    icon: HeartHandshake,
    badge: 'Guaranteed Purity',
    title: 'Batch Lab Tested',
    desc: 'Every single milling batch is rigorously verified for zero heavy metals, pesticide residues, or artificial adulterants.',
    highlight: 'Certified Traceable Quality',
    iconColor: 'from-rose-400 to-red-500 text-white shadow-rose-500/20'
  }
];

export const WhyChooseUsSection: React.FC<WhyChooseUsSectionProps> = ({ onNavigate }) => {
  return (
    <>
      <section id="why-choose-us-section" className="py-24 bg-punjab-dark text-white relative overflow-hidden">
        {/* Subtle background ambient overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-punjab/20 via-transparent to-transparent pointer-events-none" />

        <div className="container mx-auto px-6 relative z-10 mb-14 text-center">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-widest bg-punjab-gold/15 text-punjab-gold border border-punjab-gold/30 mb-3">
            <Sparkles className="w-3.5 h-3.5" /> Generational Purity
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold mb-3 tracking-tight">
            Why Choose Nirog Organic
          </h2>
          <p className="text-white/70 max-w-xl mx-auto text-xs sm:text-sm font-light leading-relaxed">
            From heirloom stone chakki milling to fair farmer partnerships, every step honors Punjab&apos;s rich agricultural heritage.
          </p>
        </div>

        {/* Continuous Smooth Left-Moving Channel / Conveyor */}
        <div className="relative w-full overflow-hidden py-4 select-none group">
          {/* Edge Vignette Fades for luxury entry/exit */}
          <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-punjab-dark via-punjab-dark/80 to-transparent z-20" />
          <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-punjab-dark via-punjab-dark/80 to-transparent z-20" />

          {/* Marquee Track moving smoothly to the left */}
          <div className="animate-marquee-smooth flex items-stretch gap-6 cursor-grab active:cursor-grabbing">
            {/* Render 2 identical sets for seamless continuous loop */}
            {[...reasons, ...reasons].map((item, idx) => {
              const Icon = item.icon;

              return (
                <div
                  key={idx}
                  className="w-[300px] sm:w-[350px] flex-shrink-0 bg-white/[0.07] backdrop-blur-xl border border-white/15 p-6 sm:p-7 rounded-3xl flex flex-col justify-between hover:bg-white/[0.12] hover:border-punjab-gold/40 transition-all duration-300 shadow-2xl hover:scale-[1.02]"
                >
                  <div>
                    {/* Top Row: Icon & Badge */}
                    <div className="flex items-center justify-between gap-3 mb-5">
                      <div
                        className={`w-13 h-13 rounded-2xl bg-gradient-to-br ${item.iconColor} p-3 flex items-center justify-center shadow-lg`}
                      >
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/10 text-punjab-gold border border-white/15">
                        {item.badge}
                      </span>
                    </div>

                    {/* Content */}
                    <h3 className="font-serif text-lg sm:text-xl font-bold mb-2 text-white">
                      {item.title}
                    </h3>
                    <p className="text-white/75 text-xs sm:text-sm font-light leading-relaxed">
                      {item.desc}
                    </p>
                  </div>

                  {/* Bottom Highlight Tag */}
                  <div className="pt-4 mt-5 border-t border-white/10 flex items-center gap-1.5 text-[11px] font-semibold text-punjab-gold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-punjab-gold flex-shrink-0" />
                    <span>{item.highlight}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Strip */}
      <section className="py-20 bg-punjab-wheat">
        <div className="container mx-auto px-6 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-punjab-soil/70 block mb-2">
            Ready to Taste the Difference?
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-punjab-soil mb-6">
            Explore Punjab&apos;s Living Pantry
          </h2>
          <button
            onClick={() => {
              onNavigate('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex items-center px-10 py-4 bg-punjab hover:bg-punjab-dark text-white rounded-full font-bold shadow-xl transition-all hover:scale-105 cursor-pointer text-sm"
          >
            Shop All Heritage Products
          </button>
        </div>
      </section>
    </>
  );
};
