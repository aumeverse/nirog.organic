@echo off
title Nirog Organic Next.js Server
echo ===================================================
echo Starting Nirog Organic Development Server...
echo ===================================================
cd /d "%~dp0"
echo Running npm install if needed...
call npm install
echo Starting server on http://localhost:3000...
start "" http://localhost:3000
call npm run dev
pause
