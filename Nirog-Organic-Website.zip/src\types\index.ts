﻿export interface Variant {
  u: string;
  p: number;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  category: 'Oils' | 'Flours' | 'Heritage Flours' | 'Spices' | 'Sweeteners' | 'Grains' | 'Gift Cards';
  img1: string;
  images?: string[];
  variants?: Variant[];
  benefits: string[];
  description?: string;
  isBestseller?: boolean;
  isOutOfStock?: boolean;
}

export interface CartItem {
  cartId: string;
  productId: string;
  product: Product;
  variantUnit: string;
  price: number;
  quantity: number;
}

export type CategoryFilter = 'All' | 'Flours' | 'Oils' | 'Heritage Flours' | 'Spices' | 'Sweeteners';

export type PageView = 'home' | 'shop' | 'checkout' | 'admin';

export interface CheckoutFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  pincode: string;
  state: string;
}

export interface ShippingRates {
  tier1: number; // <= 1kg
  tier2: number; // <= 5kg
  tier3: number; // <= 10kg
  tier4: number; // <= 20kg
  tier5: number; // > 20kg
}

export interface ShippingConfig {
  punjab: ShippingRates;
  restOfIndia: ShippingRates;
}

export type OfferBarColor = 'red' | 'orange' | 'green';

export interface OfferBarConfig {
  enabled: boolean;
  color: OfferBarColor;
  headline: string;
  description: string;
}

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  caption?: string;
}

export interface HeroConfig {
  headline: string;
  subheadline: string;
  tagline: string;
  buttonText: string;
}

export interface StoreSettings {
  whatsappNumber: string;
  offerBar: OfferBarConfig;
  hero: HeroConfig;
  videos: VideoItem[];
}
