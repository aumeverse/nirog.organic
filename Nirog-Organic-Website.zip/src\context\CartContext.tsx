﻿'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem } from '@/types';
import { useProducts } from '@/context/ProductContext';
import { parseWeightInKg } from '@/utils/shipping';

interface CartContextType {
  cart: Record<string, number>;
  cartItems: CartItem[];
  itemCount: number;
  subtotal: number;
  totalWeight: number;
  isCartOpen: boolean;
  activeModalProduct: Product | null;
  isSuccessModalOpen: boolean;
  toast: string | null;
  addToCart: (cid: string, qty?: number) => void;
  updateQty: (cid: string, delta: number) => void;
  clearCart: () => void;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  openModal: (productId: string) => void;
  closeModal: () => void;
  openSuccessModal: () => void;
  closeSuccessModal: () => void;
  showToast: (msg: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { products } = useProducts();
  const [cart, setCart] = useState<Record<string, number>>({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initialize cart from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('nirogCart');
      if (saved) {
        setCart(JSON.parse(saved));
      }
    } catch {
      localStorage.removeItem('nirogCart');
    }
    setIsLoaded(true);
  }, []);

  // Save cart to localStorage on change
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem('nirogCart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to persist cart:', e);
    }
  }, [cart, isLoaded]);

  const showToast = (msg: string) => {
    setToast(msg);
  };

  const addToCart = (cid: string, qty = 1) => {
    setCart(prev => {
      const next = { ...prev, [cid]: (prev[cid] || 0) + qty };
      return next;
    });
    showToast("Added to Harvest Box!");
    setIsCartOpen(true);
  };

  const updateQty = (cid: string, delta: number) => {
    setCart(prev => {
      const current = prev[cid] || 0;
      const nextQty = current + delta;
      const copy = { ...prev };
      if (nextQty <= 0) {
        delete copy[cid];
      } else {
        copy[cid] = nextQty;
      }
      return copy;
    });
  };

  const clearCart = () => {
    setCart({});
    try {
      localStorage.removeItem('nirogCart');
    } catch {
      // ignore
    }
  };

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);
  const toggleCart = () => setIsCartOpen(prev => !prev);

  const openModal = (productId: string) => {
    const p = products.find(item => item.id === productId);
    if (p) setActiveModalProduct(p);
  };
  const closeModal = () => setActiveModalProduct(null);

  const openSuccessModal = () => setIsSuccessModalOpen(true);
  const closeSuccessModal = () => setIsSuccessModalOpen(false);

  // Derive cart items dynamically from the product list
  const cartItems: CartItem[] = [];
  let subtotal = 0;
  let itemCount = 0;
  let totalWeight = 0;

  Object.entries(cart).forEach(([cid, qty]) => {
    if (qty <= 0) return;
    const parts = cid.split('_');
    const productId = parts[0];
    const variantKey = parts[1];
    const p = products.find(x => x.id === productId);
    if (!p) return;

    let price = p.price;
    const variantUnit = variantKey || p.unit;

    if (variantKey && p.variants) {
      const v = p.variants.find(v => v.u === variantKey);
      if (v) price = v.p;
    }

    subtotal += price * qty;
    itemCount += qty;

    if (p.id !== 'nirogcard') {
      totalWeight += parseWeightInKg(variantUnit) * qty;
    }

    cartItems.push({
      cartId: cid,
      productId: p.id,
      product: p,
      variantUnit,
      price,
      quantity: qty
    });
  });

  return (
    <CartContext.Provider
      value={{
        cart,
        cartItems,
        itemCount,
        subtotal,
        totalWeight,
        isCartOpen,
        activeModalProduct,
        isSuccessModalOpen,
        toast,
        addToCart,
        updateQty,
        clearCart,
        openCart,
        closeCart,
        toggleCart,
        openModal,
        closeModal,
        openSuccessModal,
        closeSuccessModal,
        showToast
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
