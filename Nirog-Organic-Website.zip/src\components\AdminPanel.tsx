﻿'use client';

import React, { useState, useMemo } from 'react';
import {
  Package,
  Truck,
  Lock,
  Plus,
  Search,
  Edit,
  Trash2,
  Sparkles,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  LogOut,
  RotateCcw,
  Video,
  Layout,
  Flame
} from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { useCart } from '@/context/CartContext';
import { Product, PageView } from '@/types';
import { ProductEditModal } from './admin/ProductEditModal';
import { ShippingRatesTab } from './admin/ShippingRatesTab';
import { HomepageEditorTab } from './admin/HomepageEditorTab';
import { VideosManagerTab } from './admin/VideosManagerTab';

interface AdminPanelProps {
  onNavigate: (view: PageView) => void;
}

type TabType = 'products' | 'homepage' | 'videos' | 'shipping' | 'security';

export const AdminPanel: React.FC<AdminPanelProps> = ({ onNavigate }) => {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    resetProducts,
    logout,
    updateCredentials,
    storeSettings
  } = useProducts();
  const { showToast } = useCart();

  const [activeTab, setActiveTab] = useState<TabType>('products');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [stockFilter, setStockFilter] = useState<'All' | 'inStock' | 'outOfStock'>('All');

  // Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Security credentials state
  const [newUsername, setNewUsername] = useState('jagmindarsingh');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [credMessage, setCredMessage] = useState('');

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.id.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCat =
        selectedCategory === 'All' || p.category === selectedCategory;

      const matchesStock =
        stockFilter === 'All'
          ? true
          : stockFilter === 'inStock'
          ? !p.isOutOfStock
          : !!p.isOutOfStock;

      return matchesSearch && matchesCat && matchesStock;
    });
  }, [products, searchQuery, selectedCategory, stockFilter]);

  // Metrics
  const metrics = useMemo(() => {
    const total = products.length;
    const outOfStock = products.filter((p) => p.isOutOfStock).length;
    const bestsellers = products.filter((p) => p.isBestseller).length;
    const videosCount = storeSettings.videos.length;
    return { total, outOfStock, bestsellers, videosCount };
  }, [products, storeSettings.videos]);

  const handleOpenAdd = () => {
    setEditingProduct(null);
    setIsEditModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setIsEditModalOpen(true);
  };

  const handleSaveProduct = (p: Product) => {
    if (editingProduct) {
      updateProduct(p.id, p);
      showToast(`Updated: ${p.name}`);
    } else {
      addProduct(p);
      showToast(`Created: ${p.name}`);
    }
  };

  const handleDeleteProduct = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
      deleteProduct(id);
      showToast(`Deleted: ${name}`);
    }
  };

  const handleToggleStock = (p: Product) => {
    updateProduct(p.id, { isOutOfStock: !p.isOutOfStock });
    showToast(`${p.name} is now ${!p.isOutOfStock ? 'Out of Stock' : 'In Stock'}`);
  };

  const handleToggleBestseller = (p: Product) => {
    updateProduct(p.id, { isBestseller: !p.isBestseller });
    showToast(`${p.name} bestseller status updated`);
  };

  const handleResetAllProducts = () => {
    if (confirm('Reset entire catalog to original 21 heritage products? Any custom additions will be lost.')) {
      resetProducts();
      showToast('Restored catalog to factory defaults');
    }
  };

  const handleLogout = () => {
    logout();
    showToast('Logged out of Admin Panel');
    onNavigate('home');
  };

  const handleUpdateCreds = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 4) {
      setCredMessage('Password must be at least 4 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      setCredMessage('Passwords do not match');
      return;
    }

    updateCredentials(newUsername, newPassword);
    setCredMessage('Credentials updated successfully!');
    showToast('Admin credentials saved');
    setTimeout(() => setCredMessage(''), 4000);
  };

  return (
    <div className="min-h-screen bg-punjab-cream/60 pb-20 pt-28">
      <div className="container mx-auto px-4 sm:px-6">
        {/* Top Control Bar */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-punjab-gold/20 shadow-sm mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-gray-100">
            <div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onNavigate('home')}
                  className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer"
                  title="Return to Store"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h1 className="font-serif text-3xl font-bold text-punjab-soil flex items-center gap-2.5">
                  Nirog Admin Panel
                </h1>
                <span className="px-3 py-1 bg-punjab/10 text-punjab text-xs font-bold rounded-full border border-punjab/20">
                  Admin: jagmindarsingh
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1 pl-11">
                Full administrative control over products, homepage hero, video reels, offer notch bar & WhatsApp routing.
              </p>
            </div>

            <div className="flex items-center gap-3 pl-11 md:pl-0">
              <button
                onClick={() => onNavigate('shop')}
                className="px-4 py-2.5 rounded-xl border border-gray-200 hover:border-punjab text-gray-700 hover:text-punjab text-xs font-bold transition-all cursor-pointer"
              >
                View Customer Shop
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold transition-all cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> Logout
              </button>
            </div>
          </div>

          {/* Metric Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
            <div className="bg-punjab-wheat/30 rounded-2xl p-4 border border-punjab-gold/20">
              <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Total Products</p>
              <p className="text-2xl font-serif font-bold text-punjab-soil mt-1">{metrics.total}</p>
            </div>
            <div className="bg-green-50/60 rounded-2xl p-4 border border-green-200/50">
              <p className="text-[11px] font-bold text-green-700 uppercase tracking-wider">In Stock</p>
              <p className="text-2xl font-serif font-bold text-green-800 mt-1">{metrics.total - metrics.outOfStock}</p>
            </div>
            <div className="bg-red-50/60 rounded-2xl p-4 border border-red-200/50">
              <p className="text-[11px] font-bold text-red-700 uppercase tracking-wider">Active Offer Bar</p>
              <p className="text-2xl font-serif font-bold text-red-700 mt-1 uppercase text-lg">
                {storeSettings.offerBar.enabled ? storeSettings.offerBar.color : 'Off'}
              </p>
            </div>
            <div className="bg-amber-50/60 rounded-2xl p-4 border border-amber-200/50">
              <p className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Videos Live</p>
              <p className="text-2xl font-serif font-bold text-amber-800 mt-1">{metrics.videosCount}</p>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 mt-8 pt-6 border-t border-gray-100 overflow-x-auto pb-1">
            <button
              onClick={() => setActiveTab('products')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all whitespace-nowrap ${
                activeTab === 'products'
                  ? 'bg-punjab text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Package className="w-4 h-4" /> Products ({products.length})
            </button>

            <button
              onClick={() => setActiveTab('homepage')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all whitespace-nowrap ${
                activeTab === 'homepage'
                  ? 'bg-punjab text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Layout className="w-4 h-4" /> Homepage & Offer Notch
            </button>

            <button
              onClick={() => setActiveTab('videos')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all whitespace-nowrap ${
                activeTab === 'videos'
                  ? 'bg-punjab text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Video className="w-4 h-4" /> Video Reels ({storeSettings.videos.length})
            </button>

            <button
              onClick={() => setActiveTab('shipping')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all whitespace-nowrap ${
                activeTab === 'shipping'
                  ? 'bg-punjab text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Truck className="w-4 h-4" /> Shipping Rates
            </button>

            <button
              onClick={() => setActiveTab('security')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all whitespace-nowrap ${
                activeTab === 'security'
                  ? 'bg-punjab text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Lock className="w-4 h-4" /> Security
            </button>
          </div>
        </div>

        {/* TAB 1: PRODUCTS */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-fade-in">
            {/* Filter & Action Toolbar */}
            <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
              <div className="flex flex-1 flex-col sm:flex-row gap-3">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by name, category, or ID..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium outline-none focus:border-punjab focus:bg-white"
                  />
                </div>

                {/* Category Select */}
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 outline-none focus:border-punjab"
                >
                  <option value="All">All Categories</option>
                  <option value="Flours">Flours</option>
                  <option value="Oils">Oils</option>
                  <option value="Heritage Flours">Heritage Flours</option>
                  <option value="Spices">Spices</option>
                  <option value="Sweeteners">Sweeteners</option>
                  <option value="Grains">Grains</option>
                  <option value="Gift Cards">Gift Cards</option>
                </select>

                {/* Stock Select */}
                <select
                  value={stockFilter}
                  onChange={(e) => setStockFilter(e.target.value as any)}
                  className="px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 outline-none focus:border-punjab"
                >
                  <option value="All">All Stock Status</option>
                  <option value="inStock">In Stock Only</option>
                  <option value="outOfStock">Out of Stock Only</option>
                </select>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleResetAllProducts}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:text-red-600 hover:border-red-200 text-xs font-bold transition-all cursor-pointer"
                  title="Reset to initial 21 items"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Restore 21 Products
                </button>
                <button
                  onClick={handleOpenAdd}
                  className="flex items-center gap-2 px-5 py-2.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl text-xs font-bold shadow-md transition-all hover:scale-[1.01] cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Add Product
                </button>
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="py-4 px-6">Product</th>
                      <th className="py-4 px-4">Category</th>
                      <th className="py-4 px-4">Base Unit & Price</th>
                      <th className="py-4 px-4">Variants</th>
                      <th className="py-4 px-4 text-center">Bestseller</th>
                      <th className="py-4 px-4 text-center">Stock</th>
                      <th className="py-4 px-6 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 font-medium">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-gray-500">
                          No products found matching your search and filter criteria.
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-punjab-wheat/10 transition-colors">
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className="relative flex-shrink-0">
                                <img
                                  src={p.img1}
                                  alt={p.name}
                                  className="w-12 h-12 rounded-xl object-cover border border-gray-200 shadow-xs flex-shrink-0"
                                  onError={(e) => {
                                    (e.target as HTMLElement).setAttribute(
                                      'src',
                                      'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=300'
                                    );
                                  }}
                                />
                                {p.images && p.images.length > 1 && (
                                  <span
                                    className="absolute -bottom-1 -right-1 bg-punjab text-white text-[9px] font-bold px-1 rounded-full border border-white shadow-xs"
                                    title={`${p.images.length} gallery images`}
                                  >
                                    ${p.images.length}
                                  </span>
                                )}
                              </div>
                              <div>
                                <h4 className="font-bold text-gray-900 line-clamp-1">{p.name}</h4>
                                <span className="text-[10px] text-gray-400 font-mono">#{p.id}</span>
                              </div>
                            </div>
                          </td>

                          <td className="py-4 px-4">
                            <span className="inline-block px-2.5 py-1 rounded-lg bg-punjab-wheat/50 text-punjab-soil font-semibold text-[11px] border border-punjab-gold/20">
                              {p.category}
                            </span>
                          </td>

                          <td className="py-4 px-4">
                            <div className="font-bold text-gray-800 text-sm">₹{p.price}</div>
                            <div className="text-[11px] text-gray-400">{p.unit}</div>
                          </td>

                          <td className="py-4 px-4">
                            {p.variants && p.variants.length > 0 ? (
                              <div className="flex flex-wrap gap-1 max-w-[150px]">
                                {p.variants.map((v, i) => (
                                  <span
                                    key={i}
                                    className="px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-[10px]"
                                  >
                                    {v.u}: ₹{v.p}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <span className="text-gray-400 text-[11px]">Single size</span>
                            )}
                          </td>

                          <td className="py-4 px-4 text-center">
                            <button
                              onClick={() => handleToggleBestseller(p)}
                              className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                                p.isBestseller
                                  ? 'bg-amber-100/80 border-amber-300 text-amber-700 shadow-xs'
                                  : 'bg-gray-50 border-gray-200 text-gray-400 hover:text-amber-500'
                              }`}
                              title={p.isBestseller ? 'Remove from Bestsellers' : 'Add to Bestsellers'}
                            >
                              <Sparkles className="w-4 h-4" />
                            </button>
                          </td>

                          <td className="py-4 px-4 text-center">
                            <button
                              onClick={() => handleToggleStock(p)}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold border transition-all cursor-pointer ${
                                p.isOutOfStock
                                  ? 'bg-red-50 text-red-600 border-red-200'
                                  : 'bg-green-50 text-green-700 border-green-200'
                              }`}
                            >
                              {p.isOutOfStock ? (
                                <>
                                  <XCircle className="w-3 h-3" /> Out of Stock
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="w-3 h-3" /> In Stock
                                </>
                              )}
                            </button>
                          </td>

                          <td className="py-4 px-6 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEdit(p)}
                                className="p-2 rounded-xl bg-gray-100 hover:bg-punjab/10 hover:text-punjab text-gray-600 transition-colors cursor-pointer"
                                title="Edit Product"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(p.id, p.name)}
                                className="p-2 rounded-xl bg-gray-100 hover:bg-red-50 hover:text-red-600 text-gray-600 transition-colors cursor-pointer"
                                title="Delete Product"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: HOMEPAGE & OFFER NOTCH */}
        {activeTab === 'homepage' && <HomepageEditorTab />}

        {/* TAB 3: VIDEOS & REELS */}
        {activeTab === 'videos' && <VideosManagerTab />}

        {/* TAB 4: SHIPPING */}
        {activeTab === 'shipping' && <ShippingRatesTab />}

        {/* TAB 5: SECURITY */}
        {activeTab === 'security' && (
          <div className="max-w-xl mx-auto bg-white rounded-3xl p-8 border border-gray-200 shadow-sm animate-fade-in">
            <div className="flex items-center gap-3 pb-4 border-b border-gray-100 mb-6">
              <div className="w-10 h-10 rounded-xl bg-punjab/10 text-punjab flex items-center justify-center flex-shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-xl font-bold text-punjab-soil">Admin Security</h3>
                <p className="text-xs text-gray-500">Update username and password required to enter this panel</p>
              </div>
            </div>

            {credMessage && (
              <div className="p-3 bg-punjab-wheat/50 border border-punjab-gold text-punjab-soil text-xs font-bold rounded-xl mb-4">
                {credMessage}
              </div>
            )}

            <form onSubmit={handleUpdateCreds} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Admin Username
                </label>
                <input
                  type="text"
                  required
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password (min 4 characters)"
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">
                  Confirm Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-type new password"
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium outline-none focus:border-punjab focus:bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-punjab hover:bg-punjab-dark text-white rounded-xl font-bold text-sm shadow-md transition-all hover:scale-[1.01] cursor-pointer mt-2"
              >
                Update Admin Password
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Product Edit / Add Modal */}
      <ProductEditModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveProduct}
        product={editingProduct}
      />
    </div>
  );
};
