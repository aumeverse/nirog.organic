﻿'use client';

import React, { useState } from 'react';
import { ArrowRight, X, Flame, Sparkles } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { PageView } from '@/types';

interface OfferNotchBarProps {
  onNavigate?: (view: PageView) => void;
}

export const OfferNotchBar: React.FC<OfferNotchBarProps> = ({ onNavigate }) => {
  const { storeSettings } = useProducts();
  const { offerBar } = storeSettings;
  const [isDismissed, setIsDismissed] = useState(false);

  if (!offerBar.enabled || isDismissed) return null;

  // 3 Selectable Colors: Red (default), Orange, Green
  const colorStyles = {
    red: {
      wrapper: 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white shadow-xl shadow-red-600/30 border-red-400/50',
      badge: 'bg-white/20 text-white border-white/30',
      button: 'bg-white text-red-700 hover:bg-white/95 shadow-sm'
    },
    orange: {
      wrapper: 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white shadow-xl shadow-orange-500/30 border-orange-300/50',
      badge: 'bg-white/20 text-white border-white/30',
      button: 'bg-white text-amber-800 hover:bg-white/95 shadow-sm'
    },
    green: {
      wrapper: 'bg-gradient-to-r from-emerald-600 via-green-600 to-teal-700 text-white shadow-xl shadow-green-600/30 border-emerald-400/50',
      badge: 'bg-white/20 text-white border-white/30',
      button: 'bg-white text-emerald-800 hover:bg-white/95 shadow-sm'
    }
  };

  const currentTheme = colorStyles[offerBar.color] || colorStyles.red;

  const handleShopClick = () => {
    if (onNavigate) {
      onNavigate('shop');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const el = document.getElementById('product-grid');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Repeated ticker segments for continuous seamless left-scrolling marquee
  const tickerItems = [1, 2, 3, 4];

  return (
    <div className="fixed top-[74px] sm:top-[78px] left-0 right-0 z-35 px-3 sm:px-6 pointer-events-none transition-all duration-300 animate-fade-in-up">
      <div className="container mx-auto max-w-5xl">
        <div
          className={`pointer-events-auto rounded-full py-2 px-3 sm:px-5 border backdrop-blur-md flex items-center justify-between gap-3 overflow-hidden shadow-2xl relative select-none ${currentTheme.wrapper}`}
        >
          {/* Static Left Anchor Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider border flex-shrink-0 shadow-xs z-10 backdrop-blur-md bg-black/15">
            <Flame className="w-3.5 h-3.5 text-yellow-300 animate-pulse flex-shrink-0" />
            <span className="hidden xs:inline">Special</span>
            <span>Offer</span>
          </div>

          {/* Smooth Left-Moving Scrolling Marquee Ticker */}
          <div
            className="flex-1 overflow-hidden relative flex items-center cursor-pointer group"
            onClick={handleShopClick}
            title="Click to view offers in shop (Hover to pause)"
          >
            <div className="animate-marquee-smooth flex items-center whitespace-nowrap">
              {tickerItems.map((num) => (
                <div key={num} className="flex items-center mx-4 gap-3 text-xs sm:text-sm font-semibold tracking-wide">
                  <span className="font-extrabold uppercase drop-shadow-xs">
                    {offerBar.headline}
                  </span>
                  <span className="opacity-90 font-medium text-[11px] sm:text-xs">
                    — {offerBar.description}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-white/25 border border-white/30 text-white">
                    Tap to Shop <ArrowRight className="w-2.5 h-2.5" />
                  </span>
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300 mx-2 opacity-80" />
                </div>
              ))}
            </div>
          </div>

          {/* Static Right Controls */}
          <div className="flex items-center gap-2 flex-shrink-0 z-10 pl-2 border-l border-white/20">
            <button
              onClick={handleShopClick}
              className={`px-3 py-1 rounded-full text-xs font-extrabold transition-all hover:scale-105 hidden sm:inline-flex items-center gap-1 cursor-pointer ${currentTheme.button}`}
            >
              Shop Now <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 text-white/80 hover:text-white rounded-full hover:bg-black/20 transition-colors cursor-pointer"
              aria-label="Dismiss offer notification"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
