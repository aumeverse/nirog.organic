﻿'use client';

import React from 'react';
import { Play, Video as VideoIcon } from 'lucide-react';
import { useProducts } from '@/context/ProductContext';
import { VideoItem } from '@/types';

// Helper function to resolve playable embed URLs
export const resolveVideoEmbed = (rawUrl: string): { type: 'iframe' | 'video'; embedUrl: string } => {
  const url = rawUrl.trim();

  // Direct video file
  if (url.match(/\.(mp4|webm|ogg)($|\?)/i)) {
    return { type: 'video', embedUrl: url };
  }

  // Instagram Reel or Post
  const igMatch = url.match(/instagram\.com\/(?:reel|p)\/([a-zA-Z0-9_-]+)/i);
  if (igMatch) {
    return {
      type: 'iframe',
      embedUrl: `https://www.instagram.com/reel/${igMatch[1]}/embed/`
    };
  }

  // YouTube Shorts
  const ytShortMatch = url.match(/youtube\.com\/shorts\/([a-zA-Z0-9_-]+)/i);
  if (ytShortMatch) {
    return {
      type: 'iframe',
      embedUrl: `https://www.youtube.com/embed/${ytShortMatch[1]}?autoplay=0&rel=0`
    };
  }

  // YouTube Standard / Share
  const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/))([a-zA-Z0-9_-]+)/i);
  if (ytMatch) {
    return {
      type: 'iframe',
      embedUrl: `https://www.youtube.com/embed/${ytMatch[1]}?autoplay=0&rel=0`
    };
  }

  // If already an embed URL or other service
  return { type: 'iframe', embedUrl: url };
};

export const AboutReelSection: React.FC = () => {
  const { storeSettings } = useProducts();
  const { videos } = storeSettings;

  if (!videos || videos.length === 0) return null;

  return (
    <section id="about-reel-section" className="py-20 bg-punjab-cream">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <span className="text-punjab-gold font-bold uppercase tracking-widest text-xs">
            From The Source
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-punjab-soil mt-2">
            Living Heritage In Motion
          </h2>
          <div className="w-20 h-1 bg-punjab mx-auto mt-4 rounded-full" />
          <p className="text-xs sm:text-sm text-gray-500 mt-3 max-w-xl mx-auto">
            Glimpse the pure stone-grinding, cold-pressed wood extraction, and Punjab farmland stories.
          </p>
        </div>

        {/* Dynamic Video Grid */}
        <div
          className={`grid gap-8 justify-center ${
            videos.length === 1
              ? 'grid-cols-1 max-w-md mx-auto'
              : videos.length === 2
              ? 'grid-cols-1 md:grid-cols-2 max-w-3xl mx-auto'
              : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto'
          }`}
        >
          {videos.map((vid) => {
            const { type, embedUrl } = resolveVideoEmbed(vid.url);

            return (
              <div
                key={vid.id}
                className="flex flex-col items-center bg-white/70 p-4 sm:p-5 rounded-3xl border border-punjab-gold/20 shadow-lg hover:shadow-xl transition-all"
              >
                {/* Video Player Box */}
                <div className="w-full max-w-[340px] h-[540px] sm:h-[580px] rounded-2xl overflow-hidden bg-black border border-gray-200 relative shadow-inner">
                  {type === 'video' ? (
                    <video
                      src={embedUrl}
                      controls
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <iframe
                      src={embedUrl}
                      className="w-full h-full border-none outline-none"
                      scrolling="no"
                      allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                      title={vid.title || 'Nirog Organic Video'}
                    />
                  )}
                </div>

                {/* Title & Caption */}
                <div className="mt-4 text-center max-w-[340px]">
                  <h4 className="font-serif font-bold text-base text-punjab-soil">
                    {vid.title}
                  </h4>
                  {vid.caption && (
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      {vid.caption}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
