﻿'use client';

import React from 'react';
import { Sprout, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { PageView } from '@/types';

interface HeaderProps {
  currentView: PageView;
  setView: (view: PageView) => void;
}

export const Header: React.FC<HeaderProps> = ({ setView }) => {
  const { itemCount, toggleCart } = useCart();

  const handleNavClick = (view: PageView, sectionId?: string) => {
    setView(view);
    if (sectionId) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header id="main-header" className="fixed top-0 w-full z-40 transition-all duration-300 py-4">
      <div className="container mx-auto px-6">
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-6 py-3 flex justify-between items-center shadow-lg">
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 group text-left cursor-pointer"
          >
            <Sprout className="w-10 h-10 text-punjab-gold group-hover:scale-110 transition-transform drop-shadow-md" />
            <span className="font-serif font-bold text-lg sm:text-xl text-black">Nirog Organic</span>
          </button>
          
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => handleNavClick('home')}
              className="text-black hover:text-punjab-gold font-bold text-sm uppercase transition-colors cursor-pointer"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('shop')}
              className="text-black hover:text-punjab-gold font-bold text-sm uppercase transition-colors cursor-pointer"
            >
              Shop All
            </button>
            <button
              onClick={() => handleNavClick('home', 'why-choose-us-section')}
              className="text-black hover:text-punjab-gold font-bold text-sm uppercase transition-colors cursor-pointer"
            >
              Why Us
            </button>
          </nav>

          <div className="flex items-center gap-4">
            <button
              id="cart-btn"
              onClick={toggleCart}
              className="relative bg-white text-punjab p-3 rounded-full hover:bg-punjab-gold transition-all shadow-md group cursor-pointer"
              aria-label="Open Cart"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform text-punjab" />
              <span
                id="cart-badge"
                className={`absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center transition-transform ${
                  itemCount > 0 ? 'scale-100' : 'scale-0'
                }`}
              >
                {itemCount}
              </span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
